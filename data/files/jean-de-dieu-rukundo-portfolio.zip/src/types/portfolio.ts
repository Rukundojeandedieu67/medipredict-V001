export interface Project {
  id: string;
  title: string;
  tagline: string;
  description: string;
  category: 'FinTech & Payments' | 'Cybersecurity & Auditing' | 'GovTech & Public Infrastructure' | 'Full-Stack Architecture';
  tags: string[];
  liveUrl: string;
  githubUrl: string;
  metrics: string;
  client: string;
  year: string;
  imageUrl: string;
  cloudinaryDocUrl?: string;
  featured: boolean;
  securityFeatures: string[];
}

export interface GalleryItem {
  id: string;
  title: string;
  eventType: 'Summit & Keynote' | 'Cyber Defense & CTF' | 'Innovation Hackathon' | 'Technical Workshop';
  date: string;
  location: string;
  role: string;
  description: string;
  imageUrl: string;
  cloudinaryDocUrl?: string;
  achievement?: string;
}

export interface Experience {
  id: string;
  role: string;
  company: string;
  location: string;
  period: string;
  type: 'Full-Time' | 'Lead Consultant' | 'Contract';
  summary: string;
  achievements: string[];
  technologies: string[];
}

export interface SkillCategory {
  name: string;
  skills: { name: string; level: number; highlights: string }[];
}

export interface Certification {
  id: string;
  title: string;
  issuer: string;
  date: string;
  credentialId: string;
  credentialUrl: string;
  cloudinaryDocUrl?: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  organization?: string;
  subject: string;
  message: string;
  createdAt: string;
  status: 'unread' | 'read' | 'archived';
  integrityHash: string;
}

export interface SiteSettings {
  fullName: string;
  title: string;
  secondaryTitle: string;
  email: string;
  phone: string;
  location: string;
  availability: string;
  bio: string;
  yearsOfExperience: number;
  githubUrl: string;
  linkedinUrl: string;
  twitterUrl: string;
  cloudinaryCloudName: string;
  cloudinaryUploadPreset: string;
  cloudinaryCvDocUrl: string;
  adminPasscode: string;
  backendFramework: string;
  backendApiUrl: string;
  backendDescription: string;
  databaseType: string;
  asyncEngine: string;
  rukundoStatus?: string;
  heroKicker?: string;
  heroHeadline?: string;
  heroLeadText?: string;
  metricsHighlight?: string;
  showRwandaFlagRail?: boolean;
}


export interface Education {
  degree: string;
  institution: string;
  location: string;
  period: string;
  honors?: string;
}

export interface PortfolioData {
  settings: SiteSettings;
  projects: Project[];
  gallery: GalleryItem[];
  experiences: Experience[];
  skills: SkillCategory[];
  certifications: Certification[];
  education: Education[];
  messages: ContactMessage[];
}

