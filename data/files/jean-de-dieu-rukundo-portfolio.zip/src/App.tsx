import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { ProjectsSection } from './components/ProjectsSection.tsx';
import { SecuritySpecialization } from './components/SecuritySpecialization.tsx';
import { ExperienceTimeline } from './components/ExperienceTimeline.tsx';
import { GallerySection } from './components/GallerySection.tsx';
import { SkillsSection } from './components/SkillsSection.tsx';
import { ContactSection } from './components/ContactSection.tsx';
import { Footer } from './components/Footer.tsx';
import { CVViewerModal } from './components/CVViewerModal.tsx';
import { ProjectDetailModal } from './components/ProjectDetailModal.tsx';
import { AdminPortal } from './components/AdminPortal.tsx';
import { RwandaFlagRail } from './components/RwandaFlagRail.tsx';
import { SwaggerApiModal } from './components/SwaggerApiModal.tsx';
import {
  loadPortfolioData,
  savePortfolioData,
  resetPortfolioData,
  syncWithBackend,
  submitContactMessage,
  PortfolioData,
} from './services/portfolioStore.ts';
import {
  Project,
  GalleryItem,
  ContactMessage,
  SiteSettings,
} from './types/portfolio.ts';

export default function App() {
  const [data, setData] = useState<PortfolioData>(loadPortfolioData());
  const [isDark, setIsDark] = useState<boolean>(true);
  const [cvModalOpen, setCvModalOpen] = useState<boolean>(false);
  const [adminModalOpen, setAdminModalOpen] = useState<boolean>(false);
  const [swaggerModalOpen, setSwaggerModalOpen] = useState<boolean>(false);
  const [inspectingProject, setInspectingProject] = useState<Project | null>(null);
  const [activeSection, setActiveSection] = useState<string>('projects');

  // Sync theme with document element
  useEffect(() => {
    const savedTheme = localStorage.getItem('jdr_portfolio_theme');
    if (savedTheme === 'light') {
      setIsDark(false);
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('bg-neutral-950', 'text-neutral-100');
      document.body.classList.add('bg-neutral-50', 'text-neutral-900');
    } else {
      setIsDark(true);
      document.documentElement.classList.add('dark');
      document.body.classList.add('bg-neutral-950', 'text-neutral-100');
      document.body.classList.remove('bg-neutral-50', 'text-neutral-900');
    }

    // Synchronize live state from Express backend API
    syncWithBackend().then((liveData) => {
      if (liveData) {
        setData(liveData);
      }
    });
  }, []);

  const handleToggleTheme = () => {
    const next = !isDark;
    setIsDark(next);
    localStorage.setItem('jdr_portfolio_theme', next ? 'dark' : 'light');
    if (next) {
      document.documentElement.classList.add('dark');
      document.body.classList.add('bg-neutral-950', 'text-neutral-100');
      document.body.classList.remove('bg-neutral-50', 'text-neutral-900');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('bg-neutral-950', 'text-neutral-100');
      document.body.classList.add('bg-neutral-50', 'text-neutral-900');
    }
  };

  // Section Observer for Active Section
  useEffect(() => {
    const sectionIds = ['projects', 'security', 'experience', 'gallery', 'skills', 'contact'];
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setActiveSection(entry.target.id);
          }
        });
      },
      { rootMargin: '-20% 0px -60% 0px' }
    );

    sectionIds.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  // CRUD handlers
  const handleUpdateProjects = (projects: Project[]) => {
    const next = { ...data, projects };
    setData(next);
    savePortfolioData(next);
  };

  const handleUpdateGallery = (gallery: GalleryItem[]) => {
    const next = { ...data, gallery };
    setData(next);
    savePortfolioData(next);
  };

  const handleUpdateMessages = (messages: ContactMessage[]) => {
    const next = { ...data, messages };
    setData(next);
    savePortfolioData(next);
  };

  const handleUpdateSettings = (settings: SiteSettings) => {
    const next = { ...data, settings };
    setData(next);
    savePortfolioData(next);
  };

  const handleResetData = () => {
    const initial = resetPortfolioData();
    setData(initial);
  };

  const handleImportData = (newData: PortfolioData) => {
    setData(newData);
    savePortfolioData(newData);
  };

  const handleSendMessage = (
    msgData: Omit<ContactMessage, 'id' | 'createdAt' | 'status'>
  ) => {
    const newMsg: ContactMessage = {
      ...msgData,
      id: 'msg-' + Date.now(),
      createdAt: new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      status: 'unread',
    };
    const next = { ...data, messages: [newMsg, ...data.messages] };
    setData(next);
    savePortfolioData(next);

    // Transmit to backend REST API endpoint
    submitContactMessage({
      name: msgData.name,
      email: msgData.email,
      organization: msgData.organization,
      subject: msgData.subject,
      message: msgData.message,
    }).catch((err) => console.warn('Backend message sync fallback to local cache:', err));
  };

  return (
    <div
      className={`min-h-screen flex flex-col font-sans transition-colors duration-200 pl-3 sm:pl-3.5 ${
        isDark ? 'bg-neutral-950 text-neutral-100' : 'bg-neutral-50 text-neutral-900'
      }`}
    >
      {/* Rwandan National Flag Colors Left Rail */}
      <RwandaFlagRail
        visible={data.settings.showRwandaFlagRail !== false}
        statusText={data.settings.rukundoStatus || 'Rukundo — Open for Opportunities'}
      />

      {/* Top Bar Navigation */}
      <Navbar
        settings={data.settings}
        isDark={isDark}
        onToggleTheme={handleToggleTheme}
        onOpenCV={() => setCvModalOpen(true)}
        onOpenAdmin={() => setAdminModalOpen(true)}
        onOpenSwagger={() => setSwaggerModalOpen(true)}
        activeSection={activeSection}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        <Hero
          settings={data.settings}
          onOpenCV={() => setCvModalOpen(true)}
          onOpenSwagger={() => setSwaggerModalOpen(true)}
        />

        <ProjectsSection
          projects={data.projects}
          onOpenProjectDetail={(proj) => setInspectingProject(proj)}
        />

        <SecuritySpecialization
          certifications={data.certifications}
        />

        <ExperienceTimeline
          experiences={data.experiences}
        />

        <GallerySection
          gallery={data.gallery}
        />

        <SkillsSection
          skills={data.skills}
          education={data.education}
          onOpenCV={() => setCvModalOpen(true)}
        />

        <ContactSection
          settings={data.settings}
          onSendMessage={handleSendMessage}
        />
      </main>

      {/* Footer */}
      <Footer
        settings={data.settings}
        onOpenAdmin={() => setAdminModalOpen(true)}
        onOpenCV={() => setCvModalOpen(true)}
        onOpenSwagger={() => setSwaggerModalOpen(true)}
      />

      {/* Curriculum Vitae Modal */}
      <CVViewerModal
        isOpen={cvModalOpen}
        onClose={() => setCvModalOpen(false)}
        settings={data.settings}
        experiences={data.experiences}
        projects={data.projects}
        skills={data.skills}
        certifications={data.certifications}
        education={data.education}
      />

      {/* Swagger API & Cloudinary Zero-DB Modal */}
      <SwaggerApiModal
        isOpen={swaggerModalOpen}
        onClose={() => setSwaggerModalOpen(false)}
      />

      {/* Project Architecture Deep Inspection Modal */}
      <ProjectDetailModal
        project={inspectingProject}
        onClose={() => setInspectingProject(null)}
      />

      {/* Full Admin Management Portal & Cloudinary Vault */}
      <AdminPortal
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
        data={data}
        onUpdateProjects={handleUpdateProjects}
        onUpdateGallery={handleUpdateGallery}
        onUpdateMessages={handleUpdateMessages}
        onUpdateSettings={handleUpdateSettings}
        onResetData={handleResetData}
        onImportData={handleImportData}
        onOpenSwagger={() => setSwaggerModalOpen(true)}
      />
    </div>
  );
}
