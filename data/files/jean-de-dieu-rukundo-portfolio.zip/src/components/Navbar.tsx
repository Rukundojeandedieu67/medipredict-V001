import React, { useState } from 'react';
import {
  ShieldCheck,
  Moon,
  Sun,
  Menu,
  X,
  FileText,
  Lock,
  Code2,
} from 'lucide-react';
import { SiteSettings } from '../types/portfolio.ts';

interface NavbarProps {
  settings: SiteSettings;
  isDark: boolean;
  onToggleTheme: () => void;
  onOpenCV: () => void;
  onOpenAdmin: () => void;
  onOpenSwagger: () => void;
  activeSection: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  settings,
  isDark,
  onToggleTheme,
  onOpenCV,
  onOpenAdmin,
  onOpenSwagger,
  activeSection,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Projects', href: '#projects', id: 'projects' },
    { label: 'Security', href: '#security', id: 'security' },
    { label: 'Experience', href: '#experience', id: 'experience' },
    { label: 'Gallery', href: '#gallery', id: 'gallery' },
    { label: 'Skills & CV', href: '#skills', id: 'skills' },
    { label: 'Contact', href: '#contact', id: 'contact' },
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md border-b transition-colors duration-200 bg-neutral-950/85 border-neutral-800 text-neutral-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand wordmark + Opportunities status */}
        <div className="flex items-center gap-3">
          <a
            href="#"
            className="group flex items-center gap-2.5 text-base sm:text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 rounded"
          >
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm shadow-blue-600/30">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <span className="font-semibold text-neutral-100 group-hover:text-blue-400 transition-colors">
              {settings.fullName}
            </span>
          </a>

          {/* Rukundo Open for Opportunities tag */}
          <div className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-950/60 border border-emerald-800/60 text-[11px] font-medium text-emerald-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>Open for Opportunities</span>
          </div>
        </div>

        {/* Zone 2: Nav links (concise, single-line text links) */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-neutral-400">
          {navLinks.map((link) => (
            <a
              key={link.id}
              href={link.href}
              className={`transition-colors whitespace-nowrap shrink-0 hover:text-white ${
                activeSection === link.id ? 'text-blue-400 font-semibold' : ''
              }`}
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Primary Actions (Swagger API, CV, Admin, Theme) */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onToggleTheme}
            aria-label="Toggle Color Theme"
            className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 border border-neutral-800 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
            title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-blue-400" />}
          </button>

          <button
            onClick={onOpenSwagger}
            className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-400 hover:text-emerald-300 bg-neutral-900 hover:bg-neutral-800 border border-emerald-900/50 rounded-lg transition-colors whitespace-nowrap shrink-0"
            title="Interactive Swagger OpenAPI Explorer"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Swagger API</span>
          </button>

          <button
            onClick={onOpenCV}
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-neutral-200 hover:text-white bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <FileText className="w-3.5 h-3.5 text-blue-400" />
            <span>Curriculum Vitae</span>
          </button>

          <button
            onClick={onOpenAdmin}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-all shadow-sm shadow-blue-600/20 whitespace-nowrap shrink-0 focus-visible:ring-2 focus-visible:ring-blue-400"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Admin</span>
          </button>

          {/* Mobile menu trigger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-900 border border-neutral-800"
            aria-label="Open mobile navigation"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-neutral-800 bg-neutral-950 px-4 pt-3 pb-5 space-y-2">
          {navLinks.map((link) => (
            <a
              key={link.id}
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-md text-sm font-medium text-neutral-300 hover:text-white hover:bg-neutral-900"
            >
              {link.label}
            </a>
          ))}
          <div className="pt-2 border-t border-neutral-800 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenSwagger();
              }}
              className="w-full flex items-center justify-center gap-2 py-2 text-xs font-semibold text-emerald-400 bg-neutral-900 border border-emerald-900/50 rounded-lg"
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Swagger API Explorer</span>
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenCV();
              }}
              className="w-full flex items-center justify-center gap-2 py-2 text-xs font-medium text-neutral-200 bg-neutral-900 border border-neutral-800 rounded-lg"
            >
              <FileText className="w-3.5 h-3.5 text-blue-400" />
              <span>View & Download CV</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
