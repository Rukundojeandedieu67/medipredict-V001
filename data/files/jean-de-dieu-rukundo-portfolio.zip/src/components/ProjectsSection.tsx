import React, { useState } from 'react';
import {
  ExternalLink,
  Github,
  FileText,
  Shield,
  Layers,
  CheckCircle2,
  Lock,
  ArrowUpRight,
} from 'lucide-react';
import { Project } from '../types/portfolio.ts';

interface ProjectsSectionProps {
  projects: Project[];
  onOpenProjectDetail: (project: Project) => void;
}

export const ProjectsSection: React.FC<ProjectsSectionProps> = ({
  projects,
  onOpenProjectDetail,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = [
    'All',
    'FinTech & Payments',
    'Cybersecurity & Auditing',
    'GovTech & Public Infrastructure',
    'Full-Stack Architecture',
  ];

  const filteredProjects =
    selectedCategory === 'All'
      ? projects
      : projects.filter((p) => p.category === selectedCategory);

  return (
    <section id="projects" className="py-16 lg:py-24 border-b border-neutral-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="text-xs font-semibold text-blue-400 tracking-wider uppercase">
              Selected Engineering Portfolio
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white">
              Production systems, payment switches & security tools
            </h2>
            <p className="text-sm sm:text-base text-neutral-400 leading-relaxed">
              Every project represents verified code running in production environments. Built with
              modern full-stack patterns, strict vulnerability mitigation, and zero-compromise
              availability.
            </p>
          </div>

          {/* Interactive Category Segmented Control */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-neutral-900 border border-neutral-800 rounded-xl self-start md:self-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  selectedCategory === cat
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
                }`}
              >
                {cat === 'All' ? 'All Systems' : cat}
              </button>
            ))}
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredProjects.map((project) => (
            <article
              key={project.id}
              className="group flex flex-col justify-between bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 rounded-2xl overflow-hidden transition-all duration-300 hover:shadow-xl hover:shadow-black/50"
            >
              <div>
                {/* Project Image Banner */}
                <div className="relative aspect-[16/9] w-full overflow-hidden bg-neutral-950 border-b border-neutral-800/80">
                  <img
                    src={project.imageUrl}
                    alt={project.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center group-hover:scale-[1.02] transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-transparent to-transparent" />

                  {/* Top-right direct links */}
                  <div className="absolute top-3 right-3 flex items-center gap-2">
                    {project.liveUrl && (
                      <a
                        href={project.liveUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 rounded-lg bg-neutral-950/80 backdrop-blur-md text-neutral-300 hover:text-white hover:bg-blue-600 border border-neutral-700/60 transition-colors"
                        title="Open Live Application"
                        aria-label={`Open live application for ${project.title}`}
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}
                    {project.githubUrl && (
                      <a
                        href={project.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 rounded-lg bg-neutral-950/80 backdrop-blur-md text-neutral-300 hover:text-white hover:bg-neutral-800 border border-neutral-700/60 transition-colors"
                        title="View Source Repository"
                        aria-label={`View GitHub source code for ${project.title}`}
                      >
                        <Github className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>

                  {/* Bottom context indicator */}
                  <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-xs text-neutral-300">
                    <span className="font-mono text-neutral-200 font-medium">
                      {project.client}
                    </span>
                    <span className="font-mono text-neutral-400">{project.year}</span>
                  </div>
                </div>

                {/* Content body */}
                <div className="p-6 space-y-4">
                  {/* Category unboxed metadata */}
                  <div className="flex items-center gap-2 text-xs text-blue-400 font-medium">
                    <span>{project.category}</span>
                    <span aria-hidden="true" className="text-neutral-600">·</span>
                    <span className="text-neutral-400 font-mono">{project.metrics}</span>
                  </div>

                  {/* Title and tagline */}
                  <div>
                    <h3 className="text-xl font-bold text-white group-hover:text-blue-400 transition-colors">
                      {project.title}
                    </h3>
                    <p className="mt-1 text-xs text-neutral-400 font-medium leading-relaxed">
                      {project.tagline}
                    </p>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-neutral-300 leading-relaxed">
                    {project.description}
                  </p>

                  {/* Key Security Architecture Features */}
                  <div className="pt-2 space-y-1.5 border-t border-neutral-800/80">
                    <div className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 flex items-center gap-1.5">
                      <Shield className="w-3.5 h-3.5 text-blue-400" />
                      Security & Architectural Invariants:
                    </div>
                    <ul className="grid grid-cols-1 gap-1 text-xs text-neutral-400">
                      {project.securityFeatures.slice(0, 2).map((feat, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Tags */}
                  <div className="pt-2 flex flex-wrap gap-1.5">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-[11px] font-mono px-2 py-0.5 rounded bg-neutral-800/70 text-neutral-300 border border-neutral-800"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Bottom Card Footer Actions */}
              <div className="px-6 py-4 bg-neutral-950/50 border-t border-neutral-800/80 flex items-center justify-between gap-3 text-xs">
                <button
                  onClick={() => onOpenProjectDetail(project)}
                  className="inline-flex items-center gap-1 font-semibold text-neutral-300 hover:text-white transition-colors"
                >
                  <span>Inspect System Architecture</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-blue-400" />
                </button>

                {project.cloudinaryDocUrl && (
                  <a
                    href={project.cloudinaryDocUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-neutral-400 hover:text-blue-400 transition-colors"
                    title="Read Technical Spec Sheet on Cloudinary"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Cloudinary Spec</span>
                  </a>
                )}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
