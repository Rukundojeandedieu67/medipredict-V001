import React, { useState } from 'react';
import {
  Lock,
  Unlock,
  Plus,
  Trash2,
  Edit3,
  Check,
  X,
  Save,
  RotateCcw,
  Download,
  Upload,
  Cloud,
  FileText,
  Mail,
  Layers,
  Camera,
  Settings,
  Shield,
  ExternalLink,
  Eye,
  AlertCircle,
  Copy,
  Code2,
} from 'lucide-react';
import {
  Project,
  GalleryItem,
  ContactMessage,
  SiteSettings,
  PortfolioData,
} from '../types/portfolio.ts';
import {
  syncProjectsToBackend,
  syncGalleryToBackend,
  syncSettingsToBackend,
} from '../services/portfolioStore.ts';


interface AdminPortalProps {
  isOpen: boolean;
  onClose: () => void;
  data: PortfolioData;
  onUpdateProjects: (projects: Project[]) => void;
  onUpdateGallery: (gallery: GalleryItem[]) => void;
  onUpdateMessages: (messages: ContactMessage[]) => void;
  onUpdateSettings: (settings: SiteSettings) => void;
  onResetData: () => void;
  onImportData: (data: PortfolioData) => void;
  onOpenSwagger?: () => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  isOpen,
  onClose,
  data,
  onUpdateProjects,
  onUpdateGallery,
  onUpdateMessages,
  onUpdateSettings,
  onResetData,
  onImportData,
  onOpenSwagger,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [passcodeAttempt, setPasscodeAttempt] = useState<string>('');
  const [passcodeError, setPasscodeError] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'projects' | 'gallery' | 'messages' | 'cloudinary' | 'settings' | 'swagger'>('projects');

  // Editing state for Project
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [isAddingProject, setIsAddingProject] = useState<boolean>(false);

  // Editing state for Gallery Item
  const [editingGallery, setEditingGallery] = useState<GalleryItem | null>(null);
  const [isAddingGallery, setIsAddingGallery] = useState<boolean>(false);

  // Settings local state
  const [localSettings, setLocalSettings] = useState<SiteSettings>(data.settings);
  const [settingsSaved, setSettingsSaved] = useState<boolean>(false);

  // Cloudinary document simulator state
  const [cloudinaryFileName, setCloudinaryFileName] = useState<string>('');
  const [cloudinaryDocType, setCloudinaryDocType] = useState<string>('pdf');
  const [generatedCloudinaryUrl, setGeneratedCloudinaryUrl] = useState<string>('');
  const [copiedCloudinary, setCopiedCloudinary] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcodeAttempt === data.settings.adminPasscode || passcodeAttempt === 'admin2026') {
      setIsAuthenticated(true);
      setPasscodeError(false);
      setPasscodeAttempt('');
    } else {
      setPasscodeError(true);
    }
  };

  // Project CRUD
  const handleSaveProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProject) return;

    let updatedProjects: Project[];
    if (isAddingProject) {
      updatedProjects = [editingProject, ...data.projects];
    } else {
      updatedProjects = data.projects.map((p: Project) =>
        p.id === editingProject.id ? editingProject : p
      );
    }
    onUpdateProjects(updatedProjects);
    syncProjectsToBackend(updatedProjects, data.settings.adminPasscode || 'admin2026');
    setEditingProject(null);
    setIsAddingProject(false);
  };

  const handleDeleteProject = (id: string) => {
    if (window.confirm('Are you sure you want to delete this project?')) {
      const newProjects = data.projects.filter((p: Project) => p.id !== id);
      onUpdateProjects(newProjects);
      syncProjectsToBackend(newProjects, data.settings.adminPasscode || 'admin2026');
    }
  };


  const handleStartNewProject = () => {
    const newProj: Project = {
      id: 'proj-' + Date.now(),
      title: 'New Secure System',
      tagline: 'High-performance web architecture',
      description: 'System specifications, microservices design, and security controls.',
      category: 'FinTech & Payments',
      tags: ['React', 'FastAPI', 'PostgreSQL', 'Docker'],
      liveUrl: 'https://example.rw',
      githubUrl: 'https://github.com',
      metrics: 'Sub-100ms Latency · Zero Downtime',
      client: 'Kigali Enterprise',
      year: '2026',
      imageUrl: '/src/assets/images/project_fintech_1792477420911.jpg',
      cloudinaryDocUrl: '',
      featured: false,
      securityFeatures: ['Zero-Trust RBAC', 'OWASP Top 10 Hardened'],
    };
    setEditingProject(newProj);
    setIsAddingProject(true);
  };

  // Gallery CRUD
  const handleSaveGallery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingGallery) return;

    let updatedGallery: GalleryItem[];
    if (isAddingGallery) {
      updatedGallery = [editingGallery, ...data.gallery];
    } else {
      updatedGallery = data.gallery.map((g: GalleryItem) =>
        g.id === editingGallery.id ? editingGallery : g
      );
    }
    onUpdateGallery(updatedGallery);
    syncGalleryToBackend(updatedGallery, data.settings.adminPasscode || 'admin2026');
    setEditingGallery(null);
    setIsAddingGallery(false);
  };

  const handleDeleteGallery = (id: string) => {
    if (window.confirm('Are you sure you want to delete this gallery item?')) {
      const newGallery = data.gallery.filter((g: GalleryItem) => g.id !== id);
      onUpdateGallery(newGallery);
      syncGalleryToBackend(newGallery, data.settings.adminPasscode || 'admin2026');
    }
  };


  const handleStartNewGallery = () => {
    const newItem: GalleryItem = {
      id: 'gal-' + Date.now(),
      title: 'New Tech Participation / Summit',
      eventType: 'Summit & Keynote',
      date: 'October 2026',
      location: 'Kigali Convention Centre, Rwanda',
      role: 'Keynote Speaker / Lead Architect',
      description: 'Delivering technical presentation on resilient software systems in Africa.',
      imageUrl: '/src/assets/images/gallery_hackathon_1792477422094.jpg',
      cloudinaryDocUrl: '',
      achievement: 'Excellence Award',
    };
    setEditingGallery(newItem);
    setIsAddingGallery(true);
  };

  // Message Actions
  const handleMarkMessageRead = (id: string) => {
    const newMsgs = data.messages.map((m: ContactMessage) =>
      m.id === id ? { ...m, status: (m.status === 'read' ? 'unread' : 'read') as 'unread' | 'read' } : m
    );
    onUpdateMessages(newMsgs);
  };

  const handleDeleteMessage = (id: string) => {
    const newMsgs = data.messages.filter((m: ContactMessage) => m.id !== id);
    onUpdateMessages(newMsgs);
  };


  // Settings Save
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(localSettings);
    syncSettingsToBackend(localSettings, localSettings.adminPasscode || 'admin2026');
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 2000);
  };


  // Export & Import JSON
  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(data, null, 2));
    const dlAnchor = document.createElement('a');
    dlAnchor.setAttribute('href', dataStr);
    dlAnchor.setAttribute('download', `rukundo_portfolio_backup_${Date.now()}.json`);
    dlAnchor.click();
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        onImportData(parsed);
        alert('Portfolio data successfully restored from JSON backup!');
      } catch (err) {
        alert('Invalid JSON file.');
      }
    };
    reader.readAsText(file);
  };

  // Cloudinary Direct Document Vault simulation & generator
  const handleGenerateCloudinaryDoc = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = cloudinaryFileName
      .trim()
      .replace(/[^a-zA-Z0-9_-]/g, '_');
    const cloudName = localSettings.cloudinaryCloudName || 'rwanda-tech';
    const timestamp = Math.floor(Date.now() / 1000);
    const generatedUrl = `https://res.cloudinary.com/${cloudName}/raw/upload/v${timestamp}/${cleanName}.${cloudinaryDocType}`;
    setGeneratedCloudinaryUrl(generatedUrl);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md animate-fade-in overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-5xl bg-neutral-950 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[94vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-600/20 text-blue-400 border border-blue-500/30">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold text-white">
                Admin Management Portal & CMS
              </h2>
              <div className="text-xs text-neutral-400 flex items-center gap-2">
                <span>Rukundo Portfolio Control Plane</span>
                <span aria-hidden="true">·</span>
                <span>Zero-DB Cloudinary Storage</span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors"
            aria-label="Close Admin Portal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Auth Gate */}
        {!isAuthenticated ? (
          <div className="p-8 sm:p-12 flex flex-col items-center justify-center text-center space-y-6">
            <div className="w-14 h-14 rounded-2xl bg-blue-600/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
              <Shield className="w-7 h-7" />
            </div>

            <div className="space-y-2 max-w-md">
              <h3 className="text-xl font-bold text-white">Administrator Access Required</h3>
              <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
                Enter your administrative passcode to manage live projects, gallery participations,
                incoming messages, and Cloudinary document links.
              </p>
            </div>

            <form onSubmit={handleLogin} className="w-full max-w-xs space-y-3">
              <div className="space-y-1">
                <input
                  type="password"
                  value={passcodeAttempt}
                  onChange={(e) => setPasscodeAttempt(e.target.value)}
                  placeholder="Enter passcode (default: admin2026)"
                  className="w-full px-4 py-2 text-sm rounded-lg bg-neutral-900 border border-neutral-800 text-white placeholder-neutral-500 focus:outline-none focus:ring-2 focus:ring-blue-500 text-center font-mono"
                  autoFocus
                />
                {passcodeError && (
                  <div className="text-xs text-red-400 flex items-center justify-center gap-1 mt-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>Incorrect passcode. Default is: admin2026</span>
                  </div>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-2 px-4 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors shadow-sm"
              >
                Unlock Management Console
              </button>
            </form>

            <div className="text-[11px] text-neutral-500 font-mono">
              Demo Passcode: <span className="text-neutral-400">admin2026</span>
            </div>
          </div>
        ) : (
          /* Authenticated Dashboard */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Tabs Navigation */}
            <div className="flex items-center gap-2 px-6 pt-3 border-b border-neutral-800 bg-neutral-900/40 overflow-x-auto shrink-0">
              <button
                onClick={() => setActiveTab('projects')}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
                  activeTab === 'projects'
                    ? 'border-blue-500 text-blue-400'
                    : 'border-transparent text-neutral-400 hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Projects ({data.projects.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('gallery')}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
                  activeTab === 'gallery'
                    ? 'border-blue-500 text-blue-400'
                    : 'border-transparent text-neutral-400 hover:text-white'
                }`}
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Gallery Events ({data.gallery.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('messages')}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
                  activeTab === 'messages'
                    ? 'border-blue-500 text-blue-400'
                    : 'border-transparent text-neutral-400 hover:text-white'
                }`}
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Inbox Messages ({data.messages.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('cloudinary')}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
                  activeTab === 'cloudinary'
                    ? 'border-blue-500 text-blue-400'
                    : 'border-transparent text-neutral-400 hover:text-white'
                }`}
              >
                <Cloud className="w-3.5 h-3.5" />
                <span>Cloudinary Vault (Zero-DB)</span>
              </button>

              <button
                onClick={() => setActiveTab('settings')}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
                  activeTab === 'settings'
                    ? 'border-blue-500 text-blue-400'
                    : 'border-transparent text-neutral-400 hover:text-white'
                }`}
              >
                <Settings className="w-3.5 h-3.5" />
                <span>Site Settings & Backup</span>
              </button>

              <button
                onClick={() => setActiveTab('swagger')}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors ${
                  activeTab === 'swagger'
                    ? 'border-emerald-500 text-emerald-400'
                    : 'border-transparent text-neutral-400 hover:text-white'
                }`}
              >
                <Code2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Swagger & Django API</span>
              </button>
            </div>

            {/* Tab Contents */}
            <div className="flex-1 overflow-y-auto p-6">
              {/* TAB 1: PROJECTS */}
              {activeTab === 'projects' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-base font-bold text-white">Live Project Management</h3>
                      <p className="text-xs text-neutral-400">
                        Create, modify, or remove software applications, live URLs, and Cloudinary docs.
                      </p>
                    </div>

                    <button
                      onClick={handleStartNewProject}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add New Project</span>
                    </button>
                  </div>

                  {/* Editing / Adding Form */}
                  {editingProject && (
                    <form
                      onSubmit={handleSaveProject}
                      className="p-5 rounded-xl bg-neutral-900 border border-blue-500/40 space-y-4"
                    >
                      <div className="flex items-center justify-between border-b border-neutral-800 pb-2">
                        <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">
                          {isAddingProject ? 'Add Project' : 'Edit Project'}
                        </span>
                        <button
                          type="button"
                          onClick={() => setEditingProject(null)}
                          className="text-xs text-neutral-400 hover:text-white"
                        >
                          Cancel
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">Title</label>
                          <input
                            type="text"
                            required
                            value={editingProject.title}
                            onChange={(e) =>
                              setEditingProject({ ...editingProject, title: e.target.value })
                            }
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                          />
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">Category</label>
                          <select
                            value={editingProject.category}
                            onChange={(e) =>
                              setEditingProject({
                                ...editingProject,
                                category: e.target.value as any,
                              })
                            }
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                          >
                            <option value="FinTech & Payments">FinTech & Payments</option>
                            <option value="Cybersecurity & Auditing">Cybersecurity & Auditing</option>
                            <option value="GovTech & Public Infrastructure">GovTech & Public Infrastructure</option>
                            <option value="Full-Stack Architecture">Full-Stack Architecture</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">Tagline</label>
                          <input
                            type="text"
                            value={editingProject.tagline}
                            onChange={(e) =>
                              setEditingProject({ ...editingProject, tagline: e.target.value })
                            }
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                          />
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">Client / Context</label>
                          <input
                            type="text"
                            value={editingProject.client}
                            onChange={(e) =>
                              setEditingProject({ ...editingProject, client: e.target.value })
                            }
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                          />
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">Live Application URL</label>
                          <input
                            type="text"
                            value={editingProject.liveUrl}
                            onChange={(e) =>
                              setEditingProject({ ...editingProject, liveUrl: e.target.value })
                            }
                            placeholder="https://..."
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                          />
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">GitHub Repository URL</label>
                          <input
                            type="text"
                            value={editingProject.githubUrl}
                            onChange={(e) =>
                              setEditingProject({ ...editingProject, githubUrl: e.target.value })
                            }
                            placeholder="https://github.com/..."
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                          />
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">
                            Cloudinary Document / Spec URL (Zero-DB)
                          </label>
                          <input
                            type="text"
                            value={editingProject.cloudinaryDocUrl || ''}
                            onChange={(e) =>
                              setEditingProject({
                                ...editingProject,
                                cloudinaryDocUrl: e.target.value,
                              })
                            }
                            placeholder="https://res.cloudinary.com/.../doc.pdf"
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                          />
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">Performance Metrics</label>
                          <input
                            type="text"
                            value={editingProject.metrics}
                            onChange={(e) =>
                              setEditingProject({ ...editingProject, metrics: e.target.value })
                            }
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                          />
                        </div>
                      </div>

                      <div className="text-xs">
                        <label className="text-neutral-300 font-medium block mb-1">Description</label>
                        <textarea
                          rows={3}
                          value={editingProject.description}
                          onChange={(e) =>
                            setEditingProject({ ...editingProject, description: e.target.value })
                          }
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                        />
                      </div>

                      <div className="text-xs">
                        <label className="text-neutral-300 font-medium block mb-1">
                          Tags (comma separated)
                        </label>
                        <input
                          type="text"
                          value={editingProject.tags.join(', ')}
                          onChange={(e) =>
                            setEditingProject({
                              ...editingProject,
                              tags: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                            })
                          }
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                        />
                      </div>

                      <div className="flex items-center justify-end gap-2 pt-2">
                        <button
                          type="button"
                          onClick={() => setEditingProject(null)}
                          className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg"
                        >
                          Save Project
                        </button>
                      </div>
                    </form>
                  )}

                  {/* Projects List */}
                  <div className="space-y-3">
                    {data.projects.map((proj: Project) => (
                      <div

                        key={proj.id}
                        className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-white">{proj.title}</span>
                            <span className="text-xs text-blue-400 font-mono">({proj.category})</span>
                          </div>
                          <div className="text-xs text-neutral-400 line-clamp-1">
                            {proj.tagline} · {proj.client}
                          </div>
                          <div className="flex items-center gap-3 text-[11px] font-mono text-neutral-500">
                            <span>Live: {proj.liveUrl || 'None'}</span>
                            {proj.cloudinaryDocUrl && (
                              <span className="text-blue-400">Cloudinary Doc Attached</span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => {
                              setEditingProject(proj);
                              setIsAddingProject(false);
                            }}
                            className="p-2 rounded text-neutral-400 hover:text-white hover:bg-neutral-800"
                            title="Edit Project"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteProject(proj.id)}
                            className="p-2 rounded text-neutral-400 hover:text-red-400 hover:bg-neutral-800"
                            title="Delete Project"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 2: GALLERY */}
              {activeTab === 'gallery' && (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-base font-bold text-white">Past Participations & Events</h3>
                      <p className="text-xs text-neutral-400">
                        Manage hackathons, cybersecurity drills, and continental summits.
                      </p>
                    </div>

                    <button
                      onClick={handleStartNewGallery}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add Event / Participation</span>
                    </button>
                  </div>

                  {editingGallery && (
                    <form
                      onSubmit={handleSaveGallery}
                      className="p-5 rounded-xl bg-neutral-900 border border-blue-500/40 space-y-4"
                    >
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">Title</label>
                          <input
                            type="text"
                            required
                            value={editingGallery.title}
                            onChange={(e) =>
                              setEditingGallery({ ...editingGallery, title: e.target.value })
                            }
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                          />
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">Event Type</label>
                          <select
                            value={editingGallery.eventType}
                            onChange={(e) =>
                              setEditingGallery({
                                ...editingGallery,
                                eventType: e.target.value as any,
                              })
                            }
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                          >
                            <option value="Summit & Keynote">Summit & Keynote</option>
                            <option value="Cyber Defense & CTF">Cyber Defense & CTF</option>
                            <option value="Innovation Hackathon">Innovation Hackathon</option>
                            <option value="Technical Workshop">Technical Workshop</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">Date</label>
                          <input
                            type="text"
                            value={editingGallery.date}
                            onChange={(e) =>
                              setEditingGallery({ ...editingGallery, date: e.target.value })
                            }
                            placeholder="e.g. November 2025"
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                          />
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">Location</label>
                          <input
                            type="text"
                            value={editingGallery.location}
                            onChange={(e) =>
                              setEditingGallery({ ...editingGallery, location: e.target.value })
                            }
                            placeholder="e.g. Kigali Convention Centre"
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                          />
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">Role / Award</label>
                          <input
                            type="text"
                            value={editingGallery.role}
                            onChange={(e) =>
                              setEditingGallery({ ...editingGallery, role: e.target.value })
                            }
                            placeholder="e.g. Blue Team Lead"
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                          />
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">
                            Cloudinary Certificate / Slides URL
                          </label>
                          <input
                            type="text"
                            value={editingGallery.cloudinaryDocUrl || ''}
                            onChange={(e) =>
                              setEditingGallery({
                                ...editingGallery,
                                cloudinaryDocUrl: e.target.value,
                              })
                            }
                            placeholder="https://res.cloudinary.com/.../certificate.pdf"
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                          />
                        </div>
                      </div>

                      <div className="text-xs">
                        <label className="text-neutral-300 font-medium block mb-1">Description</label>
                        <textarea
                          rows={3}
                          value={editingGallery.description}
                          onChange={(e) =>
                            setEditingGallery({ ...editingGallery, description: e.target.value })
                          }
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                        />
                      </div>

                      <div className="flex items-center justify-end gap-2 pt-2">
                        <button
                          type="button"
                          onClick={() => setEditingGallery(null)}
                          className="px-3 py-1.5 text-xs text-neutral-400 hover:text-white"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg"
                        >
                          Save Event
                        </button>
                      </div>
                    </form>
                  )}

                  <div className="space-y-3">
                    {data.gallery.map((item: GalleryItem) => (
                      <div

                        key={item.id}
                        className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 flex items-center justify-between gap-4"
                      >
                        <div>
                          <div className="text-sm font-bold text-white">{item.title}</div>
                          <div className="text-xs text-neutral-400 mt-0.5">
                            {item.eventType} · {item.location} · {item.date}
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => {
                              setEditingGallery(item);
                              setIsAddingGallery(false);
                            }}
                            className="p-2 rounded text-neutral-400 hover:text-white hover:bg-neutral-800"
                            title="Edit Event"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteGallery(item.id)}
                            className="p-2 rounded text-neutral-400 hover:text-red-400 hover:bg-neutral-800"
                            title="Delete Event"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: INBOX MESSAGES */}
              {activeTab === 'messages' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-base font-bold text-white">Client Inquiries & Auditing Requests</h3>
                    <p className="text-xs text-neutral-400">
                      Messages received through the encrypted contact form.
                    </p>
                  </div>

                  {data.messages.length === 0 ? (
                    <div className="p-8 text-center text-xs text-neutral-500 border border-dashed border-neutral-800 rounded-xl">
                      No inquiries received yet. Submissions from the contact form appear here.
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {data.messages.map((msg: ContactMessage) => (
                        <div

                          key={msg.id}
                          className={`p-4 rounded-xl border transition-colors space-y-2 ${
                            msg.status === 'unread'
                              ? 'bg-neutral-900/90 border-blue-500/50'
                              : 'bg-neutral-900/40 border-neutral-800'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold text-white">{msg.name}</span>
                              {msg.organization && (
                                <span className="text-xs text-neutral-400">
                                  ({msg.organization})
                                </span>
                              )}
                              {msg.status === 'unread' && (
                                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-blue-600/30 text-blue-400 border border-blue-500/40">
                                  NEW
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-2 text-xs">
                              <span className="text-neutral-500 font-mono">{msg.createdAt}</span>
                              <button
                                onClick={() => handleMarkMessageRead(msg.id)}
                                className="p-1 rounded text-neutral-400 hover:text-white"
                                title={msg.status === 'unread' ? 'Mark Read' : 'Mark Unread'}
                              >
                                <Check className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteMessage(msg.id)}
                                className="p-1 rounded text-neutral-400 hover:text-red-400"
                                title="Delete Message"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          <div className="text-xs font-semibold text-blue-400">{msg.subject}</div>
                          <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
                            {msg.message}
                          </p>

                          <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-xs font-mono text-neutral-500">
                            <div>Hash: {msg.integrityHash}</div>
                            <a
                              href={`mailto:${msg.email}?subject=Re: ${encodeURIComponent(msg.subject)}`}
                              className="text-blue-400 hover:underline flex items-center gap-1 font-sans"
                            >
                              <span>Reply via Email ({msg.email})</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 4: CLOUDINARY VAULT (ZERO-DB COMPLIANCE) */}
              {activeTab === 'cloudinary' && (
                <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-blue-400">
                      <Cloud className="w-5 h-5" />
                      <h3 className="text-base font-bold text-white">
                        Cloudinary Document Vault & CDN Storage
                      </h3>
                    </div>
                    <p className="text-xs text-neutral-400 leading-relaxed">
                      Per your architectural mandate: <strong className="text-neutral-200">No document or PDF files are stored in the database</strong>.
                      All whitepapers, CV versions, and certificates are hosted directly on Cloudinary CDN.
                    </p>
                  </div>

                  {/* Cloudinary Document URL Generator / Simulator */}
                  <div className="p-5 rounded-xl bg-neutral-900 border border-neutral-800 space-y-4">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                      Attach or Register New Cloudinary Document
                    </h4>

                    <form onSubmit={handleGenerateCloudinaryDoc} className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <div className="sm:col-span-2">
                        <label className="text-neutral-300 block mb-1">Document Identifier / File Name</label>
                        <input
                          type="text"
                          required
                          value={cloudinaryFileName}
                          onChange={(e) => setCloudinaryFileName(e.target.value)}
                          placeholder="e.g. Rukundo_Senior_Software_Engineer_CV"
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-neutral-300 block mb-1">File Format</label>
                        <select
                          value={cloudinaryDocType}
                          onChange={(e) => setCloudinaryDocType(e.target.value)}
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                        >
                          <option value="pdf">PDF Document (.pdf)</option>
                          <option value="docx">Word Document (.docx)</option>
                          <option value="zip">Project Archive (.zip)</option>
                        </select>
                      </div>

                      <div className="sm:col-span-3">
                        <button
                          type="submit"
                          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
                        >
                          Generate Cloudinary Raw Upload Link
                        </button>
                      </div>
                    </form>

                    {generatedCloudinaryUrl && (
                      <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800 space-y-2 text-xs">
                        <div className="text-neutral-400 font-medium">Generated Cloudinary CDN Endpoint:</div>
                        <div className="p-2 rounded bg-neutral-900 font-mono text-[11px] text-blue-400 break-all select-all">
                          {generatedCloudinaryUrl}
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(generatedCloudinaryUrl);
                              setCopiedCloudinary(true);
                              setTimeout(() => setCopiedCloudinary(false), 2000);
                            }}
                            className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-white text-[11px]"
                          >
                            {copiedCloudinary ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                            <span>{copiedCloudinary ? 'Copied' : 'Copy URL to Clipboard'}</span>
                          </button>
                          <button
                            onClick={() => {
                              setLocalSettings({ ...localSettings, cloudinaryCvDocUrl: generatedCloudinaryUrl });
                              onUpdateSettings({ ...localSettings, cloudinaryCvDocUrl: generatedCloudinaryUrl });
                              alert('Saved as your active downloadable CV URL!');
                            }}
                            className="inline-flex items-center gap-1.5 px-3 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-emerald-400 text-[11px]"
                          >
                            <span>Set as Primary CV Link</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Active Cloudinary Documents Overview */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                      Currently Attached Cloudinary Documents:
                    </h4>

                    <div className="space-y-2 text-xs">
                      <div className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 flex items-center justify-between">
                        <div>
                          <div className="font-bold text-white flex items-center gap-1.5">
                            <FileText className="w-3.5 h-3.5 text-blue-400" />
                            <span>Primary Printable CV / Resume (PDF)</span>
                          </div>
                          <div className="text-[11px] font-mono text-neutral-400 truncate max-w-lg mt-0.5">
                            {localSettings.cloudinaryCvDocUrl}
                          </div>
                        </div>
                        <a
                          href={localSettings.cloudinaryCvDocUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-400 hover:underline flex items-center gap-1"
                        >
                          <span>Open</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>

                      {data.projects.filter((p: Project) => p.cloudinaryDocUrl).map((p: Project) => (
                        <div key={p.id} className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 flex items-center justify-between">

                          <div>
                            <div className="font-bold text-white">{p.title} Architecture Whitepaper</div>
                            <div className="text-[11px] font-mono text-neutral-400 truncate max-w-lg mt-0.5">
                              {p.cloudinaryDocUrl}
                            </div>
                          </div>
                          <a
                            href={p.cloudinaryDocUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-400 hover:underline flex items-center gap-1"
                          >
                            <span>Open</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: SITE SETTINGS & BACKUP */}
              {activeTab === 'settings' && (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-base font-bold text-white">Profile & Site Configuration</h3>
                    <p className="text-xs text-neutral-400">
                      Manage identity, contact details, social links, and data persistence.
                    </p>
                  </div>

                  <form onSubmit={handleSaveSettings} className="p-5 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div>
                        <label className="text-neutral-300 font-medium block mb-1">Full Legal / Professional Name</label>
                        <input
                          type="text"
                          value={localSettings.fullName}
                          onChange={(e) => setLocalSettings({ ...localSettings, fullName: e.target.value })}
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                        />
                      </div>

                      <div>
                        <label className="text-neutral-300 font-medium block mb-1">Primary Title</label>
                        <input
                          type="text"
                          value={localSettings.title}
                          onChange={(e) => setLocalSettings({ ...localSettings, title: e.target.value })}
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                        />
                      </div>

                      <div>
                        <label className="text-neutral-300 font-medium block mb-1">Primary Email</label>
                        <input
                          type="email"
                          value={localSettings.email}
                          onChange={(e) => setLocalSettings({ ...localSettings, email: e.target.value })}
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-neutral-300 font-medium block mb-1">Phone / WhatsApp</label>
                        <input
                          type="text"
                          value={localSettings.phone}
                          onChange={(e) => setLocalSettings({ ...localSettings, phone: e.target.value })}
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-neutral-300 font-medium block mb-1">Location & Hub</label>
                        <input
                          type="text"
                          value={localSettings.location}
                          onChange={(e) => setLocalSettings({ ...localSettings, location: e.target.value })}
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                        />
                      </div>

                      <div>
                        <label className="text-neutral-300 font-medium block mb-1">Availability Status</label>
                        <input
                          type="text"
                          value={localSettings.availability}
                          onChange={(e) => setLocalSettings({ ...localSettings, availability: e.target.value })}
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                        />
                      </div>

                      <div>
                        <label className="text-neutral-300 font-medium block mb-1">Admin Passcode</label>
                        <input
                          type="text"
                          value={localSettings.adminPasscode}
                          onChange={(e) => setLocalSettings({ ...localSettings, adminPasscode: e.target.value })}
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-neutral-300 font-medium block mb-1">Cloudinary Cloud Name</label>
                        <input
                          type="text"
                          value={localSettings.cloudinaryCloudName}
                          onChange={(e) => setLocalSettings({ ...localSettings, cloudinaryCloudName: e.target.value })}
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="text-neutral-300 font-medium block mb-1">Rukundo Opportunity Tagline / Status</label>
                        <input
                          type="text"
                          value={localSettings.rukundoStatus || 'Rukundo — Open for Opportunities'}
                          onChange={(e) => setLocalSettings({ ...localSettings, rukundoStatus: e.target.value })}
                          placeholder="e.g. Rukundo — Open for Opportunities"
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-medium"
                        />
                      </div>

                      <div>
                        <label className="text-neutral-300 font-medium block mb-1">Hero Kicker (Domain Metadata)</label>
                        <input
                          type="text"
                          value={localSettings.heroKicker || 'Senior Web Application & Cybersecurity Specialist · Kigali, Rwanda'}
                          onChange={(e) => setLocalSettings({ ...localSettings, heroKicker: e.target.value })}
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                        />
                      </div>

                      <div>
                        <label className="text-neutral-300 font-medium block mb-1">Hero Dominant Headline</label>
                        <input
                          type="text"
                          value={localSettings.heroHeadline || 'Building fortified web applications & resilient distributed systems'}
                          onChange={(e) => setLocalSettings({ ...localSettings, heroHeadline: e.target.value })}
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="text-neutral-300 font-medium block mb-1">Hero Lead Narrative Text</label>
                        <textarea
                          rows={2}
                          value={localSettings.heroLeadText || ''}
                          placeholder="Hi, I'm Rukundo (Jean de Dieu Rukundo). Based in Rwanda's tech capital Kigali, I architect high-throughput fintech switches, defensive security controls, and enterprise web applications..."
                          onChange={(e) => setLocalSettings({ ...localSettings, heroLeadText: e.target.value })}
                          className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white"
                        />
                      </div>

                      <div className="sm:col-span-2 flex items-center gap-2 pt-1">
                        <input
                          type="checkbox"
                          id="showRwandaRail"
                          checked={localSettings.showRwandaFlagRail !== false}
                          onChange={(e) => setLocalSettings({ ...localSettings, showRwandaFlagRail: e.target.checked })}
                          className="rounded bg-neutral-950 border-neutral-800 text-blue-600 focus:ring-blue-500 w-4 h-4"
                        />
                        <label htmlFor="showRwandaRail" className="text-neutral-300 font-medium cursor-pointer">
                          Display Rwandan National Flag Vertical Left Rail & Ambient Glow
                        </label>
                      </div>
                    </div>

                    {/* Backend Framework & Architecture Controls */}
                    <div className="pt-4 border-t border-neutral-800/80 space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="text-xs font-bold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
                            <Layers className="w-3.5 h-3.5" />
                            <span>Backend Architecture & Framework Selection</span>
                          </h4>
                          <p className="text-[11px] text-neutral-400">
                            Configure your backend stack. Updates will immediately reflect across your live portfolio, Hero terminal badges, and project specifications.
                          </p>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            setLocalSettings({
                              ...localSettings,
                              backendFramework: 'Django REST Framework (DRF)',
                              secondaryTitle: 'Web Applications Architect · Python Django & DRF · DevSecOps · FinTech Systems',
                              backendDescription: 'Python 3.12 · Django 5.x · Django REST Framework · Celery Async Workers · PostgreSQL',
                              databaseType: 'PostgreSQL 16 (Enterprise Relational DB)',
                              asyncEngine: 'Celery & Redis Distributed Task Queue',
                            });
                          }}
                          className="px-2.5 py-1 text-[11px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 rounded hover:bg-emerald-900/60 transition-colors"
                        >
                          Apply Django Stack Preset
                        </button>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">
                            Primary Backend Framework
                          </label>
                          <select
                            value={localSettings.backendFramework || 'Django REST Framework (DRF)'}
                            onChange={(e) => setLocalSettings({ ...localSettings, backendFramework: e.target.value })}
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-medium"
                          >
                            <option value="Django REST Framework (DRF)">Django REST Framework (DRF)</option>
                            <option value="Django 5.x & Channels">Django 5.x & Channels (WebSockets)</option>
                            <option value="Python Django Full-Stack">Python Django Full-Stack</option>
                            <option value="FastAPI">FastAPI (Python Microservices)</option>
                            <option value="Node.js & Express">Node.js & Express</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">
                            Backend API Endpoint Base URL
                          </label>
                          <input
                            type="text"
                            value={localSettings.backendApiUrl || '/api'}
                            onChange={(e) => setLocalSettings({ ...localSettings, backendApiUrl: e.target.value })}
                            placeholder="/api or http://localhost:8000/api"
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                          />
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">
                            Relational Database Engine
                          </label>
                          <input
                            type="text"
                            value={localSettings.databaseType || 'PostgreSQL 16 (Enterprise Relational DB)'}
                            onChange={(e) => setLocalSettings({ ...localSettings, databaseType: e.target.value })}
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                          />
                        </div>

                        <div>
                          <label className="text-neutral-300 font-medium block mb-1">
                            Async Worker / Task Queue Engine
                          </label>
                          <input
                            type="text"
                            value={localSettings.asyncEngine || 'Celery & Redis Distributed Task Queue'}
                            onChange={(e) => setLocalSettings({ ...localSettings, asyncEngine: e.target.value })}
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="text-neutral-300 font-medium block mb-1">
                            Full Stack Pipeline Descriptor
                          </label>
                          <input
                            type="text"
                            value={localSettings.backendDescription || 'Python 3.12 · Django 5.x · Django REST Framework · Celery Async Workers · PostgreSQL'}
                            onChange={(e) => setLocalSettings({ ...localSettings, backendDescription: e.target.value })}
                            className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="text-xs pt-2">
                      <label className="text-neutral-300 font-medium block mb-1">Bio Summary</label>
                      <textarea
                        rows={3}
                        value={localSettings.bio}
                        onChange={(e) => setLocalSettings({ ...localSettings, bio: e.target.value })}
                        className="w-full p-2 rounded bg-neutral-950 border border-neutral-800 text-white leading-relaxed"
                      />
                    </div>


                    <div className="flex items-center justify-between pt-2">
                      {settingsSaved && (
                        <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                          <Check className="w-3.5 h-3.5" />
                          <span>Settings saved successfully!</span>
                        </span>
                      )}
                      <button
                        type="submit"
                        className="ml-auto inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>Update Settings</span>
                      </button>
                    </div>
                  </form>

                  {/* Export & Reset Controls */}
                  <div className="p-5 rounded-xl bg-neutral-900/40 border border-neutral-800 space-y-4">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                      Data Portability & Database Reset
                    </h4>
                    <p className="text-xs text-neutral-400">
                      Download your full portfolio state as a JSON backup or restore from an earlier backup.
                    </p>

                    <div className="flex flex-wrap items-center gap-3">
                      <button
                        onClick={handleExportJSON}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-neutral-200 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Export Full JSON Backup</span>
                      </button>

                      <label className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-neutral-200 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors cursor-pointer">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Restore from JSON File</span>
                        <input
                          type="file"
                          accept=".json"
                          onChange={handleImportJSON}
                          className="hidden"
                        />
                      </label>

                      <button
                        onClick={() => {
                          if (window.confirm('Reset all portfolio data back to default values?')) {
                            onResetData();
                          }
                        }}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-red-400 hover:text-red-300 bg-neutral-950 border border-red-900/40 hover:bg-red-950/40 rounded-lg transition-colors ml-auto"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Reset to Defaults</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 6: SWAGGER & DJANGO REST API */}
              {activeTab === 'swagger' && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-bold text-white">Django REST Framework & Swagger API</h3>
                        <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">
                          OpenAPI 3.0
                        </span>
                      </div>
                      <p className="text-xs text-neutral-400 mt-0.5">
                        Test and inspect live Django endpoints, zero-DB Cloudinary document uploads, and API specs.
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      {onOpenSwagger && (
                        <button
                          onClick={onOpenSwagger}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors shadow-sm"
                        >
                          <Code2 className="w-3.5 h-3.5" />
                          <span>Interactive Swagger Runner</span>
                        </button>
                      )}

                      <a
                        href="/api/docs"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-200 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors"
                      >
                        <span>Standalone Swagger UI</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>

                  {/* Django Architecture Summary Card */}
                  <div className="p-5 rounded-xl bg-neutral-900/60 border border-neutral-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5 text-blue-400" />
                        <span>Backend Architecture & Cloudinary Pipeline</span>
                      </span>
                      <span className="text-xs text-emerald-400 font-mono font-medium">
                        Zero-DB Compliance Active
                      </span>
                    </div>

                    <p className="text-xs text-neutral-300 leading-relaxed">
                      All documents (CVs, whitepapers, security certifications) are saved exclusively to{' '}
                      <strong className="text-white">Cloudinary CDN</strong> via the Django REST Swagger endpoint{' '}
                      <code className="text-emerald-400 font-mono px-1 py-0.5 rounded bg-neutral-950">POST /api/cloudinary/upload-doc</code>.
                      No document files or blobs are ever saved in the relational database.
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
                      <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800/80 space-y-1">
                        <div className="text-neutral-500 text-[11px]">Primary Framework</div>
                        <div className="font-semibold text-white font-mono">Python Django 5.x / DRF</div>
                      </div>
                      <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800/80 space-y-1">
                        <div className="text-neutral-500 text-[11px]">Document Storage</div>
                        <div className="font-semibold text-emerald-400 font-mono">Cloudinary CDN (Raw/PDF)</div>
                      </div>
                      <div className="p-3 rounded-lg bg-neutral-950 border border-neutral-800/80 space-y-1">
                        <div className="text-neutral-500 text-[11px]">API Documentation</div>
                        <div className="font-semibold text-blue-400 font-mono">Swagger UI & OpenAPI 3.0</div>
                      </div>
                    </div>
                  </div>

                  {/* Endpoints Table */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                      Verified Django REST Framework Endpoints:
                    </h4>

                    <div className="space-y-2 text-xs">
                      {[
                        { method: 'POST', path: '/api/cloudinary/upload-doc', desc: 'Save and register documents directly to Cloudinary CDN (Zero-DB)', tag: 'Cloudinary Docs', color: 'bg-emerald-600' },
                        { method: 'POST', path: '/api/cloudinary/generate-signature', desc: 'Generate signed raw upload parameters for direct client CDN transfer', tag: 'Cloudinary CDN', color: 'bg-emerald-600' },
                        { method: 'GET', path: '/api/projects', desc: 'List production projects with live links and Cloudinary whitepapers', tag: 'Projects', color: 'bg-blue-600' },
                        { method: 'POST', path: '/api/projects', desc: 'Create new project with tags, architecture, and live URLs', tag: 'Projects', color: 'bg-emerald-600' },
                        { method: 'GET', path: '/api/gallery', desc: 'Retrieve past participations, hackathons, and summit events', tag: 'Gallery', color: 'bg-blue-600' },
                        { method: 'POST', path: '/api/messages', desc: 'Encrypted message dispatch with SHA-256 integrity hashing', tag: 'Contact', color: 'bg-emerald-600' },
                        { method: 'GET', path: '/api/settings', desc: 'Opportunities status & profile configuration', tag: 'Settings', color: 'bg-blue-600' },
                        { method: 'GET', path: '/api/openapi.json', desc: 'Raw OpenAPI 3.0 specification definition', tag: 'System', color: 'bg-blue-600' },
                      ].map((ep) => (
                        <div
                          key={ep.path + ep.method}
                          className="p-3 rounded-lg bg-neutral-900/60 border border-neutral-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                        >
                          <div className="flex items-center gap-2">
                            <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded text-white ${ep.color}`}>
                              {ep.method}
                            </span>
                            <span className="font-mono text-white text-xs font-medium">{ep.path}</span>
                          </div>
                          <div className="text-neutral-400 text-[11px] truncate max-w-md">{ep.desc}</div>
                          <span className="text-[10px] font-mono text-neutral-500 self-start sm:self-auto shrink-0">{ep.tag}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
