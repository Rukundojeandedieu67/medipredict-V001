import React from 'react';
import { Briefcase, Calendar, MapPin, CheckCircle2 } from 'lucide-react';
import { Experience } from '../types/portfolio.ts';

interface ExperienceTimelineProps {
  experiences: Experience[];
}

export const ExperienceTimeline: React.FC<ExperienceTimelineProps> = ({ experiences }) => {
  return (
    <section id="experience" className="py-16 lg:py-24 border-b border-neutral-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Header */}
        <div className="max-w-3xl space-y-3">
          <div className="text-xs font-semibold text-blue-400 tracking-wider uppercase flex items-center gap-2">
            <Briefcase className="w-4 h-4" />
            <span>Professional Career History</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white">
            Engineering leadership across the Rwandan & East African tech ecosystem
          </h2>
          <p className="text-sm sm:text-base text-neutral-400 leading-relaxed">
            Progressing from hands-on software development to enterprise system architecture and
            lead cybersecurity advisor for mission-critical digital infrastructures.
          </p>
        </div>

        {/* Timeline Stack */}
        <div className="space-y-8 relative before:absolute before:inset-0 before:left-3 md:before:left-4 before:w-0.5 before:bg-neutral-800">
          {experiences.map((exp) => (
            <div key={exp.id} className="relative pl-9 md:pl-12 group">
              {/* Timeline marker node */}
              <div className="absolute left-1.5 md:left-2.5 top-1.5 w-3.5 h-3.5 rounded-full bg-neutral-900 border-2 border-blue-500 group-hover:bg-blue-500 transition-colors" />

              <div className="p-6 rounded-2xl bg-neutral-900/40 border border-neutral-800 hover:border-neutral-700 transition-all space-y-4">
                {/* Role header info */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800/80 pb-4">
                  <div>
                    <h3 className="text-lg sm:text-xl font-bold text-white">{exp.role}</h3>
                    <div className="text-sm font-semibold text-blue-400 mt-0.5">{exp.company}</div>
                  </div>

                  <div className="flex flex-wrap items-center gap-3 text-xs text-neutral-400 font-mono">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-neutral-400" />
                      {exp.period}
                    </span>
                    <span aria-hidden="true" className="text-neutral-600">·</span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-neutral-400" />
                      {exp.location}
                    </span>
                    <span aria-hidden="true" className="text-neutral-600">·</span>
                    <span className="text-neutral-300 font-medium">{exp.type}</span>
                  </div>
                </div>

                {/* Summary */}
                <p className="text-sm text-neutral-300 leading-relaxed">{exp.summary}</p>

                {/* Key Achievements */}
                <div className="space-y-2">
                  <div className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                    Key Outcomes & Architecture Deliverables:
                  </div>
                  <ul className="space-y-2">
                    {exp.achievements.map((ach, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-neutral-400">
                        <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                        <span>{ach}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Tech tags */}
                <div className="pt-2 flex flex-wrap gap-1.5 border-t border-neutral-800/60">
                  {exp.technologies.map((t) => (
                    <span
                      key={t}
                      className="text-[11px] font-mono px-2 py-0.5 rounded bg-neutral-800/80 text-neutral-300"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
