import React, { useState } from 'react';

interface RwandaFlagRailProps {
  visible?: boolean;
  statusText?: string;
}

export const RwandaFlagRail: React.FC<RwandaFlagRailProps> = ({
  visible = true,
  statusText = 'Rukundo — Open for Opportunities',
}) => {
  const [showTooltip, setShowTooltip] = useState(false);

  if (!visible) return null;

  return (
    <>
      {/* Vertical Fixed Left Rail in Exact Rwanda Flag Proportions */}
      <aside
        aria-label="National Identity: Republic of Rwanda"
        className="fixed left-0 top-0 bottom-0 w-3 sm:w-3.5 z-50 flex flex-col shadow-xl shadow-black/60 select-none group cursor-pointer"
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        onClick={() => setShowTooltip(!showTooltip)}
      >
        {/* Top 50%: Sky Blue (#00A1DE) with Rwanda's 24-ray Golden Sun */}
        <div className="h-[50%] bg-[#00A1DE] relative flex items-center justify-center overflow-hidden">
          {/* Subtle Golden Sun Emblem at top */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 opacity-95 group-hover:scale-125 transition-transform duration-300">
            <svg
              className="w-3.5 h-3.5 text-[#FAD201] animate-spin"
              style={{ animationDuration: '30s' }}
              viewBox="0 0 24 24"
              fill="currentColor"
            >
              <circle cx="12" cy="12" r="4" fill="#FAD201" />
              {Array.from({ length: 24 }).map((_, i) => (
                <line
                  key={i}
                  x1="12"
                  y1="2"
                  x2="12"
                  y2="5"
                  stroke="#FAD201"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  transform={`rotate(${i * 15} 12 12)`}
                />
              ))}
            </svg>
          </div>
        </div>

        {/* Middle 25%: Sun Yellow (#FAD201) */}
        <div className="h-[25%] bg-[#FAD201]" />

        {/* Bottom 25%: Forest Green (#20603D) */}
        <div className="h-[25%] bg-[#20603D]" />

        {/* Hover / Interactive Tooltip Card */}
        <div
          className={`absolute left-full top-20 ml-3 transition-all duration-200 z-50 pointer-events-auto ${
            showTooltip
              ? 'opacity-100 translate-x-0'
              : 'opacity-0 -translate-x-2 pointer-events-none'
          }`}
        >
          <div className="px-3.5 py-2.5 rounded-xl bg-neutral-900/95 border border-neutral-700/80 shadow-2xl backdrop-blur-md text-xs text-white whitespace-nowrap min-w-[240px]">
            <div className="flex items-center gap-2 font-bold mb-1">
              <span className="text-base">🇷🇼</span>
              <span className="text-neutral-100">Republic of Rwanda</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 font-mono">
                Kigali Hub
              </span>
            </div>
            <div className="text-[11px] text-emerald-400 font-medium flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>{statusText}</span>
            </div>
            <div className="text-[10px] text-neutral-400 mt-1 border-t border-neutral-800 pt-1">
              National Pride · Senior Django & React Architect
            </div>
          </div>
        </div>
      </aside>

      {/* Left side ambient color gradient glow */}
      <div
        className="fixed left-0 top-0 bottom-0 w-28 pointer-events-none z-10 opacity-15 bg-gradient-to-r from-[#00A1DE]/25 via-[#FAD201]/10 to-transparent"
        aria-hidden="true"
      />
    </>
  );
};
