import React from 'react';
import { ShieldCheck, ArrowUp, Lock, Github, Linkedin, Mail, Code2 } from 'lucide-react';
import { SiteSettings } from '../types/portfolio.ts';

interface FooterProps {
  settings: SiteSettings;
  onOpenAdmin: () => void;
  onOpenCV: () => void;
  onOpenSwagger?: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  settings,
  onOpenAdmin,
  onOpenCV,
  onOpenSwagger,
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="no-print bg-neutral-950 border-t border-neutral-800 text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          {/* Brand & Identity */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded bg-blue-600 flex items-center justify-center text-white">
                <ShieldCheck className="w-3.5 h-3.5" />
              </div>
              <span className="font-bold text-white text-sm">{settings.fullName} (Rukundo)</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-medium">
                🇷🇼 Open for Opportunities
              </span>
            </div>
            <p className="text-neutral-400 max-w-sm">
              {settings.title} · Based in Kigali, Rwanda. Open for senior software engineering
              contracts, Django REST backends, and cybersecurity audits.
            </p>
          </div>

          {/* Social Links & Shortcuts */}
          <div className="flex flex-wrap items-center gap-3">
            <a
              href={settings.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg bg-neutral-900 border border-neutral-800 hover:text-white transition-colors"
              aria-label="GitHub Profile"
            >
              <Github className="w-4 h-4" />
            </a>

            <a
              href={settings.linkedinUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-lg bg-neutral-900 border border-neutral-800 hover:text-white transition-colors"
              aria-label="LinkedIn Profile"
            >
              <Linkedin className="w-4 h-4" />
            </a>

            <a
              href={`mailto:${settings.email}`}
              className="p-2 rounded-lg bg-neutral-900 border border-neutral-800 hover:text-white transition-colors"
              aria-label="Send direct email"
            >
              <Mail className="w-4 h-4" />
            </a>

            {onOpenSwagger && (
              <button
                onClick={onOpenSwagger}
                className="px-3 py-1.5 rounded-lg bg-neutral-900 border border-emerald-900/60 hover:text-emerald-300 text-emerald-400 font-semibold flex items-center gap-1.5 transition-colors"
              >
                <Code2 className="w-3.5 h-3.5" />
                <span>Swagger API</span>
              </button>
            )}

            <button
              onClick={onOpenCV}
              className="px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 hover:text-white font-medium transition-colors"
            >
              View CV
            </button>

            <button
              onClick={onOpenAdmin}
              className="px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 hover:text-blue-400 font-medium flex items-center gap-1.5 transition-colors"
            >
              <Lock className="w-3 h-3" />
              <span>Admin Portal</span>
            </button>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 border-t border-neutral-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-500">
          <div>
            © {new Date().getFullYear()} {settings.fullName}. React + Python Django (DRF) · Cloudinary Zero-DB Document Vault · Rwanda Flag Left Rail.
          </div>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <span>🇷🇼 Kigali, Rwanda (CAT · UTC+2)</span>
            </span>
            <button
              onClick={scrollToTop}
              className="hover:text-white transition-colors flex items-center gap-1"
            >
              <span>Back to Top</span>
              <ArrowUp className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
