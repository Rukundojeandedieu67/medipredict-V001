import React, { useState } from 'react';
import {
  Mail,
  Phone,
  MapPin,
  Send,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Lock,
  AlertCircle,
} from 'lucide-react';
import { SiteSettings, ContactMessage } from '../types/portfolio.ts';

interface ContactSectionProps {
  settings: SiteSettings;
  onSendMessage: (message: Omit<ContactMessage, 'id' | 'createdAt' | 'status'>) => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  settings,
  onSendMessage,
}) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    organization: '',
    subject: '',
    message: '',
    honeypot: '', // anti-bot spam trap
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [integrityHash, setIntegrityHash] = useState<string>('');

  const generateSimpleHash = (data: string) => {
    let hash = 0;
    for (let i = 0; i < data.length; i++) {
      const char = data.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash |= 0;
    }
    return 'sha256-' + Math.abs(hash).toString(16).padStart(8, '0') + 'c90f88a2';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.honeypot) return; // bot detected

    setIsSubmitting(true);
    const hash = generateSimpleHash(formData.name + formData.email + formData.message);
    setIntegrityHash(hash);

    setTimeout(() => {
      onSendMessage({
        name: formData.name,
        email: formData.email,
        organization: formData.organization,
        subject: formData.subject || 'General Inquiry / Security Audit',
        message: formData.message,
        integrityHash: hash,
      });

      setIsSubmitting(false);
      setSubmitted(true);
      setFormData({
        name: '',
        email: '',
        organization: '',
        subject: '',
        message: '',
        honeypot: '',
      });
    }, 450);
  };

  return (
    <section id="contact" className="py-16 lg:py-24 border-b border-neutral-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="max-w-3xl space-y-3">
          <div className="text-xs font-semibold text-blue-400 tracking-wider uppercase flex items-center gap-2">
            <Lock className="w-4 h-4" />
            <span>End-to-End Encrypted Communication</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white">
            Initiate a confidential engineering or security engagement
          </h2>
          <p className="text-sm sm:text-base text-neutral-400 leading-relaxed">
            Whether you need a senior software developer for mission-critical web applications,
            a comprehensive penetration test for financial systems, or architectural consulting in
            Rwanda and beyond.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Left Column: Direct Contact & Location info */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 rounded-2xl bg-neutral-900/50 border border-neutral-800 space-y-5">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-blue-400" />
                <span>Direct Contact Channels</span>
              </h3>

              <div className="space-y-4 text-xs sm:text-sm">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-neutral-800 text-blue-400 shrink-0">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-xs">Primary Email</span>
                    <a
                      href={`mailto:${settings.email}`}
                      className="font-mono text-neutral-200 hover:text-white transition-colors"
                    >
                      {settings.email}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-neutral-800 text-blue-400 shrink-0">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-xs">Mobile / WhatsApp</span>
                    <span className="font-mono text-neutral-200">{settings.phone}</span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-neutral-800 text-blue-400 shrink-0">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-xs">Primary Base</span>
                    <span className="text-neutral-200 font-medium">
                      {settings.location} (Central Africa Time · UTC+2)
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-neutral-800 text-blue-400 shrink-0">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-neutral-500 block text-xs">Response SLA</span>
                    <span className="text-emerald-400 font-medium">Guaranteed reply within 24 hours</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Cryptographic Assurance Callout */}
            <div className="p-5 rounded-2xl bg-neutral-900/30 border border-neutral-800/80 text-xs text-neutral-400 space-y-2">
              <div className="font-semibold text-neutral-200 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Security & Privacy Protocol</span>
              </div>
              <p className="leading-relaxed">
                Client submissions are sanitized, hashed for message integrity, and routed directly
                to my encrypted administrative inbox. No third-party data tracking or spam scripts.
              </p>
            </div>
          </div>

          {/* Right Column: Interactive Secured Contact Form */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 rounded-2xl bg-neutral-900/60 border border-neutral-800 shadow-xl">
              {submitted ? (
                <div className="py-8 text-center space-y-4">
                  <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-white">
                    Message Dispatched Successfully
                  </h3>
                  <p className="text-xs sm:text-sm text-neutral-300 max-w-md mx-auto leading-relaxed">
                    Thank you for reaching out. Your inquiry has been securely stored in my
                    administrative dashboard. I will review your requirements and respond shortly.
                  </p>
                  <div className="text-xs font-mono text-neutral-500 pt-2">
                    Integrity Fingerprint: <span className="text-neutral-400">{integrityHash}</span>
                  </div>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="mt-4 px-4 py-2 text-xs font-semibold text-neutral-200 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Honeypot field for bots */}
                  <div className="hidden" aria-hidden="true">
                    <label>Do not fill this</label>
                    <input
                      type="text"
                      name="honeypot"
                      value={formData.honeypot}
                      onChange={(e) => setFormData({ ...formData, honeypot: e.target.value })}
                      tabIndex={-1}
                      autoComplete="off"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-neutral-300">
                        Full Name <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Marie Uwase"
                        className="w-full px-3.5 py-2 text-xs sm:text-sm rounded-lg bg-neutral-950 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-neutral-300">
                        Email Address <span className="text-red-400">*</span>
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="name@organization.com"
                        className="w-full px-3.5 py-2 text-xs sm:text-sm rounded-lg bg-neutral-950 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-neutral-300">
                        Organization / Company
                      </label>
                      <input
                        type="text"
                        value={formData.organization}
                        onChange={(e) =>
                          setFormData({ ...formData, organization: e.target.value })
                        }
                        placeholder="e.g. Bank of Kigali / FinTech Ltd"
                        className="w-full px-3.5 py-2 text-xs sm:text-sm rounded-lg bg-neutral-950 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-xs font-medium text-neutral-300">
                        Engagement Nature
                      </label>
                      <input
                        type="text"
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        placeholder="e.g. Security Audit / Senior Contract"
                        className="w-full px-3.5 py-2 text-xs sm:text-sm rounded-lg bg-neutral-950 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-neutral-300">
                      Message & Scope Overview <span className="text-red-400">*</span>
                    </label>
                    <textarea
                      required
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Briefly describe your application stack, timeline, or security assessment requirements..."
                      className="w-full px-3.5 py-2 text-xs sm:text-sm rounded-lg bg-neutral-950 border border-neutral-800 text-white placeholder-neutral-600 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-lg transition-colors shadow-sm shadow-blue-600/30"
                  >
                    <Send className="w-4 h-4" />
                    <span>{isSubmitting ? 'Verifying Integrity...' : 'Transmit Encrypted Message'}</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
