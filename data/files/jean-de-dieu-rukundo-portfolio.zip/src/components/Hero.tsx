import React from 'react';
import {
  ShieldCheck,
  FileDown,
  ArrowRight,
  ExternalLink,
  MapPin,
  Clock,
  Terminal,
  Lock,
  Code2,
  Sparkles,
} from 'lucide-react';
import { SiteSettings } from '../types/portfolio.ts';

interface HeroProps {
  settings: SiteSettings;
  onOpenCV: () => void;
  onOpenSwagger?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ settings, onOpenCV, onOpenSwagger }) => {
  return (
    <section className="relative pt-12 pb-16 lg:pt-16 lg:pb-24 border-b border-neutral-800/80 overflow-hidden">
      {/* Subtle background ambient grid (pure CSS) */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20 bg-[linear-gradient(to_right,#262626_1px,transparent_1px),linear-gradient(to_bottom,#262626_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"
        aria-hidden="true"
      />

      {/* Left side Rwanda ambient color beam */}
      <div
        className="absolute -left-10 top-1/4 w-40 h-80 rounded-full blur-3xl pointer-events-none opacity-20 bg-gradient-to-b from-[#00A1DE] via-[#FAD201] to-[#20603D]"
        aria-hidden="true"
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Split Screen 2-Column Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Typographic Hierarchy & Rwandan Identity */}
          <div className="lg:col-span-7 space-y-6">
            {/* Prominent "Rukundo — Open for Opportunities" & Rwanda Flag Badge */}
            <div className="flex flex-wrap items-center gap-2.5">
              {/* National Flag Badge */}
              <div className="inline-flex items-center overflow-hidden rounded-md border border-neutral-700/80 shadow-sm bg-neutral-900/90 h-6">
                <div className="flex flex-col h-full w-5 justify-between">
                  <div className="h-[50%] bg-[#00A1DE] flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#FAD201]" />
                  </div>
                  <div className="h-[25%] bg-[#FAD201]" />
                  <div className="h-[25%] bg-[#20603D]" />
                </div>
                <span className="px-2 text-[11px] font-semibold text-neutral-200">
                  Republic of Rwanda 🇷🇼
                </span>
              </div>

              {/* Rukundo Open for Opportunities live status */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-700/70 text-xs font-semibold text-emerald-300 shadow-sm shadow-emerald-950">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span>{settings.rukundoStatus || 'Rukundo — Open for Opportunities'}</span>
              </div>
            </div>

            {/* Domain Kicker (unboxed clean metadata) */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-blue-400 tracking-wide">
              <span>{settings.heroKicker || 'Senior Web Application & Cybersecurity Specialist'}</span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1 text-neutral-400">
                <MapPin className="w-3.5 h-3.5 text-blue-400" />
                {settings.location}
              </span>
            </div>

            {/* Dominant Hero Headline (with text-wrap: balance) */}
            <h1
              className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-[1.15]"
              style={{ textWrap: 'balance' }}
            >
              {settings.heroHeadline || 'Building fortified web applications & resilient distributed systems'}
            </h1>

            {/* Lead Narrative */}
            <p className="text-base sm:text-lg text-neutral-300 leading-relaxed font-normal">
              {settings.heroLeadText ? (
                settings.heroLeadText
              ) : (
                <>
                  Hi, I'm <strong className="text-white font-semibold">{settings.fullName} (Rukundo)</strong>.
                  Based in Rwanda's tech capital Kigali, I engineer high-throughput fintech switches,
                  defensive cybersecurity controls, and enterprise web applications. Specialized in{' '}
                  <span className="text-neutral-100 font-medium">React, Python Django (DRF), PostgreSQL,</span> and
                  zero-DB Cloudinary document pipelines.
                </>
              )}
            </p>

            {/* Operational Status & Timezone */}
            <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-neutral-400">
              <div className="flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-blue-400" />
                <span className="text-neutral-300 font-medium">{settings.availability}</span>
              </div>
              <span aria-hidden="true" className="text-neutral-600">·</span>
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-neutral-400" />
                <span>Kigali Time (CAT / UTC+2)</span>
              </div>
            </div>

            {/* Action Buttons Group */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              <a
                href="#projects"
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors shadow-sm shadow-blue-600/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 whitespace-nowrap shrink-0"
              >
                <span>Explore Live Projects</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <button
                onClick={onOpenCV}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-neutral-200 hover:text-white bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500"
              >
                <FileDown className="w-4 h-4 text-blue-400" />
                <span>View & Download CV (PDF)</span>
              </button>

              {onOpenSwagger && (
                <button
                  onClick={onOpenSwagger}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-emerald-400 hover:text-emerald-300 bg-neutral-900 hover:bg-neutral-800 border border-emerald-900/60 rounded-lg transition-colors whitespace-nowrap shrink-0"
                >
                  <Code2 className="w-4 h-4 text-emerald-400" />
                  <span>Swagger API Explorer</span>
                </button>
              )}

              <a
                href="#contact"
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-neutral-400 hover:text-white transition-colors whitespace-nowrap shrink-0"
              >
                <span>Request Security Audit</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Architecture Highlights Note */}
            <div className="pt-2 text-xs text-neutral-400 flex flex-wrap items-center gap-2">
              <span className="font-semibold text-neutral-200">Production Architecture:</span>
              <span className="px-2 py-0.5 rounded bg-blue-950/50 text-blue-300 border border-blue-900/50 font-mono text-[11px]">
                React SPA
              </span>
              <span className="px-2 py-0.5 rounded bg-emerald-950/50 text-emerald-300 border border-emerald-900/50 font-mono text-[11px]">
                Python Django (DRF)
              </span>
              <span className="px-2 py-0.5 rounded bg-sky-950/50 text-sky-300 border border-sky-900/50 font-mono text-[11px]">
                Cloudinary Zero-DB
              </span>
              <span className="px-2 py-0.5 rounded bg-neutral-800 text-neutral-300 border border-neutral-700 font-mono text-[11px]">
                Swagger 3.0 API
              </span>
            </div>
          </div>

          {/* Right Column: High-Fidelity Editorial Visual Container */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            <div className="relative w-full max-w-md">
              {/* Outer Minimalist Frame */}
              <div className="relative rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-900 shadow-xl shadow-black/40 aspect-[4/3]">
                <img
                  src="/src/assets/images/hero_portrait_1792477419987.jpg"
                  alt="Jean de Dieu Rukundo - Senior Software Engineer & Cybersecurity Specialist in Kigali"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top hover:scale-[1.02] transition-transform duration-500"
                />

                {/* Scrim overlay with essential identity metadata */}
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/90 via-transparent to-transparent flex flex-col justify-end p-5">
                  <div className="text-sm font-semibold text-white flex items-center gap-2">
                    <span>{settings.fullName}</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-medium">
                      Open for Opportunities
                    </span>
                  </div>
                  <div className="text-xs text-neutral-300 flex items-center gap-1.5 mt-0.5">
                    <span>🇷🇼 Kigali, Rwanda</span>
                    <span aria-hidden="true">·</span>
                    <span>Senior Tech Lead & Cybersecurity</span>
                  </div>
                </div>
              </div>

              {/* Decorative terminal highlight badge */}
              <div className="mt-3 px-3 py-2 rounded-lg bg-neutral-900/90 border border-neutral-800 text-xs text-neutral-400 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-blue-400" />
                  <span className="text-neutral-300 font-mono text-[11px]">
                    Django 5.x · DRF · Swagger · Cloudinary
                  </span>
                </span>
                <span className="text-emerald-400 font-mono text-[11px] font-semibold">8+ YOE</span>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width Metric Strip Below Hero Split */}
        <div className="mt-14 pt-8 border-t border-neutral-800/80 grid grid-cols-2 sm:grid-cols-4 gap-6 lg:gap-8">
          <div className="space-y-1">
            <div className="text-2xl sm:text-3xl font-bold font-mono text-white tabular-nums tracking-tight">
              8+ Years
            </div>
            <div className="text-xs text-neutral-400">
              Enterprise Software & API Architecture
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-2xl sm:text-3xl font-bold font-mono text-white tabular-nums tracking-tight">
              1.4M+
            </div>
            <div className="text-xs text-neutral-400">
              FinTech Transactions Safely Routed
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-2xl sm:text-3xl font-bold font-mono text-white tabular-nums tracking-tight">
              45+
            </div>
            <div className="text-xs text-neutral-400">
              Security Audits & Vulnerability Pentests
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-2xl sm:text-3xl font-bold font-mono text-white tabular-nums tracking-tight">
              Zero-DB
            </div>
            <div className="text-xs text-neutral-400">
              Docs Safely Saved on Cloudinary CDN
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
