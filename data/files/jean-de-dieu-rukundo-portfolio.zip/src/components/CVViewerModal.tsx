import React, { useState } from 'react';
import {
  Printer,
  FileDown,
  ExternalLink,
  Copy,
  Check,
  X,
  Mail,
  Phone,
  MapPin,
  Globe,
  Award,
  Briefcase,
  GraduationCap,
  Shield,
  Layers,
} from 'lucide-react';
import {
  SiteSettings,
  Experience,
  Project,
  SkillCategory,
  Certification,
  Education,
} from '../types/portfolio.ts';

interface CVViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SiteSettings;
  experiences: Experience[];
  projects: Project[];
  skills: SkillCategory[];
  certifications: Certification[];
  education: Education[];
}

export const CVViewerModal: React.FC<CVViewerModalProps> = ({
  isOpen,
  onClose,
  settings,
  experiences,
  projects,
  skills,
  certifications,
  education,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleCopyPlainText = () => {
    const plainText = `
${settings.fullName}
${settings.title}
Email: ${settings.email} | Phone: ${settings.phone} | Location: ${settings.location}
LinkedIn: ${settings.linkedinUrl} | GitHub: ${settings.githubUrl}

PROFESSIONAL SUMMARY:
${settings.bio}

CORE TECHNICAL SKILLS:
${skills.map((c) => `${c.name}: ${c.skills.map((s) => s.name).join(', ')}`).join('\n')}

CERTIFICATIONS:
${certifications.map((c) => `- ${c.title} (${c.issuer}, ${c.date}) - ID: ${c.credentialId}`).join('\n')}

WORK EXPERIENCE:
${experiences
  .map(
    (e) => `
${e.role} | ${e.company} (${e.period}) - ${e.location}
${e.summary}
Key Deliverables:
${e.achievements.map((a) => `  * ${a}`).join('\n')}
Technologies: ${e.technologies.join(', ')}
`
  )
  .join('\n')}

FEATURED PRODUCTION PROJECTS:
${projects
  .map(
    (p) => `
* ${p.title} (${p.year}) - ${p.client}
  Tagline: ${p.tagline}
  Live URL: ${p.liveUrl} | GitHub: ${p.githubUrl}
  Metrics: ${p.metrics}
`
  )
  .join('\n')}

EDUCATION:
${education.map((ed) => `- ${ed.degree}, ${ed.institution} (${ed.period})`).join('\n')}
    `.trim();

    navigator.clipboard.writeText(plainText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-fade-in overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Control Bar (Hidden when printing) */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-950/90 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-white">Curriculum Vitae</span>
            <span className="text-xs text-neutral-400">· ATS-Compliant Format</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyPlainText}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors"
              title="Copy plain text CV to clipboard"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Text'}</span>
            </button>

            {settings.cloudinaryCvDocUrl && (
              <a
                href={settings.cloudinaryCvDocUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors"
                title="Download original PDF directly from Cloudinary"
              >
                <FileDown className="w-3.5 h-3.5 text-blue-400" />
                <span>Cloudinary PDF</span>
              </a>
            )}

            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors shadow-sm"
              title="Print directly or save as PDF via browser"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Save / Print PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors ml-2"
              aria-label="Close CV modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Printable Document Area */}
        <div
          id="printable-cv"
          className="p-6 sm:p-10 overflow-y-auto bg-neutral-900 text-neutral-100 print:bg-white print:text-black space-y-8"
        >
          {/* Header section */}
          <div className="border-b border-neutral-800 print:border-neutral-300 pb-6 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white print:text-black tracking-tight">
                  {settings.fullName}
                </h1>
                <p className="text-sm sm:text-base font-semibold text-blue-400 print:text-neutral-700 mt-1">
                  {settings.title}
                </p>
                <p className="text-xs text-neutral-400 print:text-neutral-600 mt-0.5">
                  {settings.secondaryTitle}
                </p>
              </div>

              {/* Contact info block */}
              <div className="text-xs space-y-1 text-neutral-300 print:text-neutral-700 font-mono">
                <div className="flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-blue-400 print:text-black" />
                  <a href={`mailto:${settings.email}`} className="hover:underline">
                    {settings.email}
                  </a>
                </div>
                <div className="flex items-center gap-1.5">
                  <Phone className="w-3.5 h-3.5 text-blue-400 print:text-black" />
                  <span>{settings.phone}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-blue-400 print:text-black" />
                  <span>{settings.location} (CAT / UTC+2)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Globe className="w-3.5 h-3.5 text-blue-400 print:text-black" />
                  <span>LinkedIn & GitHub Active</span>
                </div>
              </div>
            </div>

            {/* Executive Bio */}
            <div className="pt-2">
              <p className="text-xs sm:text-sm text-neutral-300 print:text-neutral-800 leading-relaxed">
                {settings.bio}
              </p>
            </div>
          </div>

          {/* Industry Certifications */}
          <div className="space-y-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-blue-400 print:text-black flex items-center gap-1.5 border-b border-neutral-800 print:border-neutral-300 pb-1">
              <Award className="w-4 h-4" />
              <span>Industry Certifications & Accreditations</span>
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {certifications.map((cert) => (
                <div key={cert.id} className="p-2.5 rounded bg-neutral-950/40 print:bg-neutral-100 border border-neutral-800 print:border-neutral-200">
                  <div className="font-bold text-white print:text-black">{cert.title}</div>
                  <div className="text-neutral-400 print:text-neutral-700 flex justify-between mt-1">
                    <span>{cert.issuer} ({cert.date})</span>
                    <span className="font-mono">ID: {cert.credentialId}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Work Experience */}
          <div className="space-y-4">
            <h2 className="text-sm font-bold uppercase tracking-wider text-blue-400 print:text-black flex items-center gap-1.5 border-b border-neutral-800 print:border-neutral-300 pb-1">
              <Briefcase className="w-4 h-4" />
              <span>Professional Experience</span>
            </h2>

            <div className="space-y-5">
              {experiences.map((exp) => (
                <div key={exp.id} className="space-y-2">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs">
                    <div>
                      <span className="text-sm font-bold text-white print:text-black">{exp.role}</span>
                      <span className="text-neutral-400 print:text-neutral-600"> · {exp.company}</span>
                    </div>
                    <span className="font-mono text-neutral-400 print:text-neutral-600 mt-0.5 sm:mt-0">
                      {exp.period} | {exp.location}
                    </span>
                  </div>

                  <p className="text-xs text-neutral-300 print:text-neutral-800 leading-relaxed">
                    {exp.summary}
                  </p>

                  <ul className="list-disc list-inside space-y-1 text-xs text-neutral-400 print:text-neutral-700">
                    {exp.achievements.map((ach, idx) => (
                      <li key={idx} className="leading-relaxed">
                        {ach}
                      </li>
                    ))}
                  </ul>

                  <div className="text-[11px] font-mono text-neutral-400 print:text-neutral-600">
                    <span className="font-semibold text-neutral-300 print:text-neutral-800">Technologies: </span>
                    {exp.technologies.join(', ')}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Key Featured Projects with Live Links */}
          <div className="space-y-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-blue-400 print:text-black flex items-center gap-1.5 border-b border-neutral-800 print:border-neutral-300 pb-1">
              <Layers className="w-4 h-4" />
              <span>Selected Key Projects & Production Systems</span>
            </h2>

            <div className="space-y-3">
              {projects.slice(0, 3).map((proj) => (
                <div key={proj.id} className="p-3 rounded bg-neutral-950/40 print:bg-neutral-50 border border-neutral-800 print:border-neutral-200 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="font-bold text-white print:text-black text-sm">
                      {proj.title} <span className="font-normal text-neutral-400 print:text-neutral-600">({proj.category})</span>
                    </div>
                    <span className="font-mono text-neutral-400 print:text-neutral-600">{proj.year}</span>
                  </div>
                  <p className="text-neutral-300 print:text-neutral-700 leading-relaxed">
                    {proj.description}
                  </p>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] font-mono text-neutral-400 print:text-neutral-600">
                    <span>Client: {proj.client}</span>
                    <span>Metrics: {proj.metrics}</span>
                    {proj.liveUrl && (
                      <span className="text-blue-400 print:text-blue-700">Live: {proj.liveUrl}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Technical Skills Categorized */}
          <div className="space-y-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-blue-400 print:text-black flex items-center gap-1.5 border-b border-neutral-800 print:border-neutral-300 pb-1">
              <Shield className="w-4 h-4" />
              <span>Core Technical Competencies</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {skills.map((cat, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="font-semibold text-neutral-200 print:text-neutral-900">
                    {cat.name}:
                  </div>
                  <div className="text-neutral-400 print:text-neutral-700">
                    {cat.skills.map((s) => s.name).join(' · ')}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Academic Background */}
          <div className="space-y-3">
            <h2 className="text-sm font-bold uppercase tracking-wider text-blue-400 print:text-black flex items-center gap-1.5 border-b border-neutral-800 print:border-neutral-300 pb-1">
              <GraduationCap className="w-4 h-4" />
              <span>Education & Fellowships</span>
            </h2>

            <div className="space-y-2 text-xs">
              {education.map((edu, idx) => (
                <div key={idx}>
                  <div className="flex justify-between font-bold text-white print:text-black">
                    <span>{edu.degree}</span>
                    <span className="font-mono font-normal text-neutral-400 print:text-neutral-600">{edu.period}</span>
                  </div>
                  <div className="text-neutral-400 print:text-neutral-600">{edu.institution} · {edu.location}</div>
                  {edu.honors && (
                    <div className="text-[11px] text-neutral-300 print:text-neutral-700 mt-0.5">{edu.honors}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
