import React from 'react';
import {
  Code2,
  GraduationCap,
  Layers,
  CheckCircle,
  FileDown,
  Terminal,
} from 'lucide-react';
import { SkillCategory, Education } from '../types/portfolio.ts';

interface SkillsSectionProps {
  skills: SkillCategory[];
  education: Education[];
  onOpenCV: () => void;
}

export const SkillsSection: React.FC<SkillsSectionProps> = ({
  skills,
  education,
  onOpenCV,
}) => {
  return (
    <section id="skills" className="py-16 lg:py-24 border-b border-neutral-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="max-w-2xl space-y-3">
            <div className="text-xs font-semibold text-blue-400 tracking-wider uppercase flex items-center gap-2">
              <Code2 className="w-4 h-4" />
              <span>Full-Stack & Security Competencies</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white">
              Technical arsenal honed for high-stakes software engineering
            </h2>
            <p className="text-sm sm:text-base text-neutral-400 leading-relaxed">
              Specialized across the modern web stack, asynchronous backend architectures, and
              comprehensive offensive and defensive cybersecurity auditing frameworks.
            </p>
          </div>

          <button
            onClick={onOpenCV}
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors shadow-sm shadow-blue-600/20 whitespace-nowrap self-start md:self-auto shrink-0"
          >
            <FileDown className="w-4 h-4" />
            <span>Examine Full Printable CV</span>
          </button>
        </div>

        {/* 4 Skill Category Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {skills.map((category, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-neutral-900/50 border border-neutral-800 space-y-5"
            >
              <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2 border-b border-neutral-800 pb-3">
                <span className="w-2 h-2 rounded-full bg-blue-500" />
                <span>{category.name}</span>
              </h3>

              <div className="space-y-4">
                {category.skills.map((skill, sIdx) => (
                  <div key={sIdx} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs sm:text-sm">
                      <span className="font-semibold text-neutral-200">{skill.name}</span>
                      <span className="font-mono text-xs text-blue-400 font-semibold tabular-nums">
                        {skill.level}%
                      </span>
                    </div>

                    {/* Clean progress bar */}
                    <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-blue-600 to-indigo-500 rounded-full"
                        style={{ width: `${skill.level}%` }}
                      />
                    </div>

                    <div className="text-[11px] text-neutral-400 font-mono">
                      {skill.highlights}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Education & Academic Excellence */}
        <div className="pt-8 border-t border-neutral-800 space-y-6">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <GraduationCap className="w-5 h-5 text-blue-400" />
            <span>Academic Background & Executive Fellowships</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {education.map((edu, idx) => (
              <div
                key={idx}
                className="p-6 rounded-xl bg-neutral-900/40 border border-neutral-800 space-y-2"
              >
                <div className="text-sm font-bold text-white">{edu.degree}</div>
                <div className="text-xs font-semibold text-blue-400">{edu.institution}</div>
                <div className="text-xs font-mono text-neutral-400 flex items-center gap-2">
                  <span>{edu.location}</span>
                  <span aria-hidden="true">·</span>
                  <span>{edu.period}</span>
                </div>
                {edu.honors && (
                  <p className="text-xs text-neutral-300 pt-1 leading-relaxed">
                    {edu.honors}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
