import React from 'react';
import {
  ShieldAlert,
  Terminal,
  FileCheck,
  Award,
  CheckCircle,
  ExternalLink,
  Cpu,
  Lock,
} from 'lucide-react';
import { Certification } from '../types/portfolio.ts';

interface SecuritySpecializationProps {
  certifications: Certification[];
}

export const SecuritySpecialization: React.FC<SecuritySpecializationProps> = ({
  certifications,
}) => {
  const auditingDisciplines = [
    {
      title: 'Web Application & API Penetration Testing',
      description:
        'Methodical black-box and grey-box security assessments targeting OWASP Top 10, broken object-level authorization (BOLA), business logic flaws, and rate-limit bypasses.',
      tools: 'Burp Suite Pro · OWASP ZAP · Postman Security Suites · Custom Python Scrapers',
    },
    {
      title: 'FinTech Ledger Integrity & Cryptographic Auditing',
      description:
        'Auditing payment switches, mobile wallet callbacks, and cryptographic key lifecycles against PCI-DSS and ISO 20022 security baselines.',
      tools: 'HSM Integration · AES-256-GCM · HMAC-SHA256 Signatures · Tokenization Bridges',
    },
    {
      title: 'Automated DevSecOps & Cloud Hardening',
      description:
        'Integrating static & dynamic security analyzers into CI/CD pipelines. Preventing hardcoded secrets, misconfigured Dockerfiles, and vulnerable dependencies from reaching production.',
      tools: 'Trivy · Snyk · SonarQube · GitHub Actions Security Gates · Docker Bench',
    },
    {
      title: 'Zero-Trust Architecture & Identity Management',
      description:
        'Architecting least-privilege role-based access control (RBAC), multi-factor hardware key verification (FIDO2), and mutual TLS (mTLS) service mesh encryption.',
      tools: 'OAuth 2.0 / OIDC · JWT Claims Enforcement · WireGuard · NGINX Strict TLS 1.3',
    },
  ];

  return (
    <section id="security" className="py-16 lg:py-24 border-b border-neutral-800/80 bg-neutral-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="max-w-3xl space-y-3">
          <div className="text-xs font-semibold text-blue-400 tracking-wider uppercase flex items-center gap-2">
            <ShieldAlert className="w-4 h-4" />
            <span>Offensive & Defensive Security Specialization</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white">
            Fortifying digital infrastructure against sophisticated threats
          </h2>
          <p className="text-sm sm:text-base text-neutral-400 leading-relaxed">
            Cybersecurity is not an afterthought or a compliance checkbox; it is the fundamental
            bedrock of every web application I engineer. Below are my core security disciplines and
            verified industry credentials.
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {auditingDisciplines.map((item, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-neutral-900/40 border border-neutral-800 hover:border-neutral-700 transition-colors space-y-3"
            >
              <div className="text-xs font-mono text-blue-400 font-semibold">
                0{idx + 1}. Discipline
              </div>
              <h3 className="text-lg font-bold text-white">{item.title}</h3>
              <p className="text-sm text-neutral-300 leading-relaxed">{item.description}</p>
              <div className="pt-2 text-xs font-mono text-neutral-400 border-t border-neutral-800/60">
                <span className="text-neutral-500">Tooling: </span>
                <span className="text-neutral-300">{item.tools}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Industry Certifications Strip */}
        <div className="pt-8 border-t border-neutral-800 space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-amber-400" />
              <span>Accreditations & Industry Certifications</span>
            </h3>
            <span className="text-xs text-neutral-400 font-mono">100% Cryptographically Verifiable</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {certifications.map((cert) => (
              <div
                key={cert.id}
                className="p-4 rounded-xl bg-neutral-900/60 border border-neutral-800 flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="text-xs font-semibold text-blue-400">{cert.issuer}</div>
                  <div className="text-sm font-bold text-white mt-1 leading-snug">{cert.title}</div>
                  <div className="text-xs font-mono text-neutral-400 mt-2">
                    ID: {cert.credentialId}
                  </div>
                </div>

                <div className="pt-2 border-t border-neutral-800 flex items-center justify-between text-xs">
                  <span className="text-neutral-400">{cert.date}</span>
                  <div className="flex items-center gap-2">
                    {cert.cloudinaryDocUrl && (
                      <a
                        href={cert.cloudinaryDocUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-neutral-400 hover:text-white"
                        title="View Certificate PDF on Cloudinary"
                      >
                        <FileCheck className="w-3.5 h-3.5" />
                      </a>
                    )}
                    <a
                      href={cert.credentialUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-400 hover:text-blue-300 flex items-center gap-1 font-medium"
                    >
                      <span>Verify</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
