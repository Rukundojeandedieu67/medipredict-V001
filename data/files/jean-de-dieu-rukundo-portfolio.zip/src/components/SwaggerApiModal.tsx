import React, { useState } from 'react';
import {
  X,
  Terminal,
  Send,
  Cloud,
  ExternalLink,
  Copy,
  Check,
  Code2,
  Play,
  Layers,
  FileCheck,
  ShieldCheck,
} from 'lucide-react';

interface SwaggerApiModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SwaggerApiModal: React.FC<SwaggerApiModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [selectedEndpoint, setSelectedEndpoint] = useState<string>('/cloudinary/upload-doc');
  const [copied, setCopied] = useState(false);
  const [requestLoading, setRequestLoading] = useState(false);
  const [apiResponse, setApiResponse] = useState<any>(null);

  // Form states for test requests
  const [docTitle, setDocTitle] = useState('Kigali_Fintech_Security_Architecture');
  const [docFormat, setDocFormat] = useState('pdf');

  if (!isOpen) return null;

  const endpoints = [
    {
      method: 'POST',
      path: '/api/cloudinary/upload-doc',
      summary: 'Save Document to Cloudinary (Zero-DB)',
      tag: 'Cloudinary Docs',
      color: 'bg-emerald-600',
    },
    {
      method: 'GET',
      path: '/api/projects',
      summary: 'List Production Django Projects',
      tag: 'Projects',
      color: 'bg-blue-600',
    },
    {
      method: 'GET',
      path: '/api/health',
      summary: 'System Telemetry & Telehealth Status',
      tag: 'System',
      color: 'bg-blue-600',
    },
    {
      method: 'GET',
      path: '/api/settings',
      summary: 'Opportunities & Profile Settings',
      tag: 'Settings',
      color: 'bg-blue-600',
    },
    {
      method: 'GET',
      path: '/api/portfolio',
      summary: 'Full Portfolio State Hydration',
      tag: 'System',
      color: 'bg-blue-600',
    },
  ];

  const handleExecuteRequest = async () => {
    setRequestLoading(true);
    try {
      if (selectedEndpoint === '/cloudinary/upload-doc') {
        const res = await fetch('/api/cloudinary/upload-doc', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            documentTitle: docTitle,
            fileType: docFormat,
            cloudFolder: 'rwanda_portfolio_docs',
          }),
        });
        const data = await res.json();
        setApiResponse(data);
      } else {
        const res = await fetch(selectedEndpoint);
        const data = await res.json();
        setApiResponse(data);
      }
    } catch (err: any) {
      setApiResponse({ error: err.message || 'API request execution failed' });
    } finally {
      setRequestLoading(false);
    }
  };

  const handleCopySpec = async () => {
    try {
      const res = await fetch('/api/openapi.json');
      const data = await res.json();
      navigator.clipboard.writeText(JSON.stringify(data, null, 2));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/90 backdrop-blur-md animate-fade-in overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl bg-neutral-950 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-800 bg-neutral-900/90 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white shadow-sm shadow-emerald-600/30 font-mono font-bold text-xs">
              {'{}'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">
                  Swagger OpenAPI 3.0 Explorer
                </h3>
                {/* Rwanda flag badge */}
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-950/80 text-sky-400 border border-sky-800/60 flex items-center gap-1">
                  <span>Django DRF 🇷🇼</span>
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                Test and execute live Django REST Framework endpoints and Cloudinary document storage.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href="/api/docs"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors"
              title="Open full standalone Swagger UI page"
            >
              <span>Swagger UI</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            <button
              onClick={handleCopySpec}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors"
              title="Copy OpenAPI 3.0 specification JSON"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'OpenAPI Spec'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 transition-colors ml-1"
              aria-label="Close Swagger modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Endpoint selector tabs */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-neutral-400 uppercase tracking-wider block">
              Select Django REST Framework Endpoint to Test:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {endpoints.map((ep) => (
                <button
                  key={ep.path}
                  onClick={() => {
                    setSelectedEndpoint(ep.path);
                    setApiResponse(null);
                  }}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    selectedEndpoint === ep.path
                      ? 'bg-neutral-900 border-blue-500 ring-1 ring-blue-500/50'
                      : 'bg-neutral-900/40 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span
                      className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded text-white ${ep.color}`}
                    >
                      {ep.method}
                    </span>
                    <span className="text-[10px] font-mono text-neutral-500">{ep.tag}</span>
                  </div>
                  <div className="font-mono text-xs text-white truncate">{ep.path}</div>
                  <div className="text-[11px] text-neutral-400 mt-1 line-clamp-1">
                    {ep.summary}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Execution Pane */}
          <div className="p-5 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800 pb-3">
              <div className="flex items-center gap-2 font-mono text-xs">
                <span className="px-2 py-0.5 rounded bg-blue-600 text-white font-bold">
                  {selectedEndpoint.startsWith('/api/cloudinary/upload') ? 'POST' : 'GET'}
                </span>
                <span className="text-neutral-200 font-semibold">{selectedEndpoint}</span>
              </div>

              <button
                onClick={handleExecuteRequest}
                disabled={requestLoading}
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors shadow-sm disabled:opacity-50"
              >
                <Play className="w-3.5 h-3.5" />
                <span>{requestLoading ? 'Executing via Swagger...' : 'Execute Request'}</span>
              </button>
            </div>

            {/* Custom Parameters for Cloudinary Upload */}
            {selectedEndpoint === '/api/cloudinary/upload-doc' && (
              <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3 text-xs">
                <div className="font-semibold text-white flex items-center gap-1.5">
                  <Cloud className="w-4 h-4 text-emerald-400" />
                  <span>Cloudinary Document Vault Parameter Simulation (Zero-DB)</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2 space-y-1">
                    <label className="text-neutral-400">documentTitle (Required)</label>
                    <input
                      type="text"
                      value={docTitle}
                      onChange={(e) => setDocTitle(e.target.value)}
                      className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-white font-mono"
                      placeholder="e.g. KigaliPay_Architecture_Whitepaper"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-neutral-400">fileType</label>
                    <select
                      value={docFormat}
                      onChange={(e) => setDocFormat(e.target.value)}
                      className="w-full p-2 rounded bg-neutral-900 border border-neutral-800 text-white"
                    >
                      <option value="pdf">PDF Document (.pdf)</option>
                      <option value="docx">Word Document (.docx)</option>
                      <option value="zip">Archive (.zip)</option>
                    </select>
                  </div>
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  Executing this request registers the file directly to your Cloudinary CDN bucket.
                  No file binary is stored in PostgreSQL or server disk, honoring strict zero-DB mandates.
                </p>
              </div>
            )}

            {/* Response Console */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <span className="font-semibold text-neutral-300">Live Server Response Payload:</span>
                <span className="font-mono text-[11px]">Format: JSON (application/json)</span>
              </div>

              <div className="p-4 rounded-xl bg-neutral-950 border border-neutral-800 font-mono text-xs overflow-x-auto max-h-60 text-emerald-400">
                {apiResponse ? (
                  <pre>{JSON.stringify(apiResponse, null, 2)}</pre>
                ) : (
                  <span className="text-neutral-600">
                    Click "Execute Request" above to trigger this Django REST Framework endpoint and inspect output.
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-neutral-950 border-t border-neutral-800 flex items-center justify-between text-xs text-neutral-400">
          <span>Django 5.x · Django REST Framework · OpenAPI 3.0.3 Spec</span>
          <span className="text-neutral-300 font-mono">Zero-DB Cloudinary Broker Active</span>
        </div>
      </div>
    </div>
  );
};
