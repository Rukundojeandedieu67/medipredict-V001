import React, { useState } from 'react';
import {
  Camera,
  Calendar,
  MapPin,
  Award,
  ExternalLink,
  FileText,
  X,
  Maximize2,
} from 'lucide-react';
import { GalleryItem } from '../types/portfolio.ts';

interface GallerySectionProps {
  gallery: GalleryItem[];
}

export const GallerySection: React.FC<GallerySectionProps> = ({ gallery }) => {
  const [activeModalItem, setActiveModalItem] = useState<GalleryItem | null>(null);
  const [filterType, setFilterType] = useState<string>('All');

  const filterOptions = [
    'All',
    'Summit & Keynote',
    'Cyber Defense & CTF',
    'Innovation Hackathon',
    'Technical Workshop',
  ];

  const filteredItems =
    filterType === 'All'
      ? gallery
      : gallery.filter((item) => item.eventType === filterType);

  return (
    <section id="gallery" className="py-16 lg:py-24 border-b border-neutral-800/80 bg-neutral-950/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="max-w-2xl space-y-3">
            <div className="text-xs font-semibold text-blue-400 tracking-wider uppercase flex items-center gap-2">
              <Camera className="w-4 h-4" />
              <span>Past Participations & Continental Summits</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-white">
              Hackathons, cyber drills & keynote showcases
            </h2>
            <p className="text-sm sm:text-base text-neutral-400 leading-relaxed">
              Active contributor to Rwanda's tech renaissance: representing national cyber defense
              teams, pitching fintech innovations, and mentoring the next generation of East African
              software engineers.
            </p>
          </div>

          {/* Filter tabs */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-neutral-900 border border-neutral-800 rounded-xl self-start md:self-auto">
            {filterOptions.map((opt) => (
              <button
                key={opt}
                onClick={() => setFilterType(opt)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                  filterType === opt
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/60'
                }`}
              >
                {opt === 'All' ? 'All Events' : opt}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery Grid (Bento & Masonry style) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="group bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 rounded-2xl overflow-hidden flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-black/50"
            >
              <div>
                {/* Photo container */}
                <div
                  onClick={() => setActiveModalItem(item)}
                  className="relative aspect-[4/3] w-full overflow-hidden bg-neutral-950 cursor-pointer"
                >
                  <img
                    src={item.imageUrl}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-transparent to-transparent" />

                  {/* Top-right zoom action button */}
                  <div className="absolute top-3 right-3 p-2 rounded-lg bg-neutral-950/70 backdrop-blur-md text-white opacity-0 group-hover:opacity-100 transition-opacity">
                    <Maximize2 className="w-3.5 h-3.5" />
                  </div>

                  {/* Category tag */}
                  <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-xs text-neutral-300">
                    <span className="font-semibold text-blue-400">{item.eventType}</span>
                    <span className="font-mono text-neutral-400">{item.date}</span>
                  </div>
                </div>

                {/* Details */}
                <div className="p-5 space-y-3">
                  <h3 className="text-base font-bold text-white group-hover:text-blue-400 transition-colors leading-snug">
                    {item.title}
                  </h3>

                  <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-400">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-neutral-400" />
                      {item.location}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="text-neutral-300">{item.role}</span>
                  </div>

                  <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
                    {item.description}
                  </p>

                  {item.achievement && (
                    <div className="pt-2 flex items-start gap-1.5 text-xs font-semibold text-amber-400">
                      <Award className="w-4 h-4 shrink-0 mt-0.5" />
                      <span>{item.achievement}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Bottom bar */}
              <div className="px-5 py-3 bg-neutral-950/50 border-t border-neutral-800/80 flex items-center justify-between text-xs">
                <button
                  onClick={() => setActiveModalItem(item)}
                  className="text-neutral-300 hover:text-white font-medium"
                >
                  View High-Res Photo
                </button>

                {item.cloudinaryDocUrl && (
                  <a
                    href={item.cloudinaryDocUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-blue-400 hover:text-blue-300"
                    title="View Certificate / Commendation on Cloudinary"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Certificate Doc</span>
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal (Fullscreen Clean Media Viewer) */}
      {activeModalItem && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/90 backdrop-blur-md animate-fade-in"
          onClick={() => setActiveModalItem(null)}
        >
          <div
            className="relative w-full max-w-4xl bg-neutral-950 border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 border-b border-neutral-800 bg-neutral-900/80">
              <div>
                <h3 className="text-base font-bold text-white">{activeModalItem.title}</h3>
                <div className="text-xs text-neutral-400 flex items-center gap-2 mt-0.5">
                  <span>{activeModalItem.eventType}</span>
                  <span aria-hidden="true">·</span>
                  <span>{activeModalItem.location}</span>
                  <span aria-hidden="true">·</span>
                  <span>{activeModalItem.date}</span>
                </div>
              </div>
              <button
                onClick={() => setActiveModalItem(null)}
                className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-neutral-800 border border-neutral-800 transition-colors"
                aria-label="Close photo preview"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Image */}
            <div className="relative aspect-[16/10] sm:aspect-[16/9] w-full bg-black">
              <img
                src={activeModalItem.imageUrl}
                alt={activeModalItem.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain"
              />
            </div>

            {/* Modal Info Footer */}
            <div className="p-5 bg-neutral-900/90 border-t border-neutral-800 space-y-2">
              <p className="text-sm text-neutral-200 leading-relaxed">
                {activeModalItem.description}
              </p>
              {activeModalItem.achievement && (
                <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-400">
                  <Award className="w-4 h-4 shrink-0" />
                  <span>Honored: {activeModalItem.achievement}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
