import {
  Project,
  GalleryItem,
  Experience,
  Certification,
  ContactMessage,
  SiteSettings,
  SkillCategory,
  Education,
  PortfolioData,
} from '../types/portfolio.ts';

export type { PortfolioData };



export const DEFAULT_SETTINGS: SiteSettings = {
  fullName: 'Jean de Dieu Rukundo',
  title: 'Senior Software Engineer & Cybersecurity Specialist',
  secondaryTitle: 'Web Applications Architect · Python Django & DRF · DevSecOps · FinTech Systems',
  email: 'rukundojeandedieu67@gmail.com',
  phone: '+250 788 492 810',
  location: 'Kigali, Rwanda',
  availability: 'Available for Senior Engineering Roles & Enterprise Security Consulting',
  bio: 'A high-impact Senior Software Engineer and Cybersecurity Specialist based in Kigali, Rwanda. Over 8+ years designing zero-trust web architectures, mission-critical Django & DRF fintech switches, resilient PostgreSQL schemas, and fortified cloud systems.',
  yearsOfExperience: 8,
  githubUrl: 'https://github.com',
  linkedinUrl: 'https://linkedin.com',
  twitterUrl: 'https://twitter.com',
  cloudinaryCloudName: 'rwanda-tech-portfolio',
  cloudinaryUploadPreset: 'portfolio_docs',
  cloudinaryCvDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477400/Jean_de_Dieu_Rukundo_CV.pdf',
  adminPasscode: 'admin2026',
  backendFramework: 'Django REST Framework (DRF)',
  backendApiUrl: '/api',
  backendDescription: 'Python 3.12 · Django 5.x · Django REST Framework · Celery Async Workers · PostgreSQL',
  databaseType: 'PostgreSQL 16 (Enterprise Relational DB)',
  asyncEngine: 'Celery & Redis Distributed Task Queue',
  rukundoStatus: 'Rukundo — Open for Opportunities',
  heroKicker: 'Senior Web Application & Cybersecurity Specialist · Kigali, Rwanda',
  heroHeadline: 'Building fortified web applications & resilient distributed systems',
  heroLeadText: "Hi, I'm Rukundo (Jean de Dieu Rukundo). Based in Rwanda's tech hub Kigali, I architect mission-critical Django REST Framework backends, high-performance React web applications, and enterprise cybersecurity systems.",
  showRwandaFlagRail: true,
};

export const DEFAULT_PROJECTS: Project[] = [
  {
    id: 'proj-1',
    title: 'KigaliPay Interoperable Gateway',
    tagline: 'High-throughput multi-channel payment gateway and USSD settlement engine',
    description: 'Architected and implemented a bank-grade payment switch integrating MTN Mobile Money (MoMo), Airtel Money, and Visa/Mastercard processing. Built with Django REST Framework and Celery async workers. Features zero-downtime ledger reconciliation, tokenized card vaulting, and sub-second USSD session termination.',
    category: 'FinTech & Payments',
    tags: ['React', 'Python Django', 'Django REST Framework', 'PostgreSQL', 'Celery', 'Redis', 'Docker', 'PCI-DSS'],
    liveUrl: 'https://kigalipay-demo.rw',
    githubUrl: 'https://github.com/rukundojd/kigalipay-core',
    metrics: '99.98% Uptime · 1.4M Transactions Processed · <120ms Latency',
    client: 'East Africa Digital Payments Consortium',
    year: '2025',
    imageUrl: '/src/assets/images/project_fintech_1792477420911.jpg',
    cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477401/KigaliPay_Architecture_Whitepaper.pdf',
    featured: true,
    securityFeatures: [
      'HSM-backed cryptographic tokenization',
      'Real-time AML & fraud heuristics engine',
      'Idempotent transactional ledger with double-entry audit',
      'Django Security Middleware & OWASP API Top 10 automated compliance'
    ],
  },
  {
    id: 'proj-2',
    title: 'AegisSec SOC & Threat Intelligence Portal',
    tagline: 'Cloud-native vulnerability assessment and automated CIS benchmark scanner',
    description: 'A comprehensive cyber defense operations console designed for financial institutions and government agencies across East Africa. Built with Django REST Framework backend services. Aggregates network telemetry, automates continuous penetration tests, and enforces Zero-Trust RBAC with tamper-proof audit trails.',
    category: 'Cybersecurity & Auditing',
    tags: ['React', 'Python Django', 'DRF', 'PostgreSQL', 'Wazuh', 'Trivy', 'Tailwind CSS'],
    liveUrl: 'https://aegissec-soc.rw',
    githubUrl: 'https://github.com/rukundojd/aegissec-threat-platform',
    metrics: '45+ Enterprise Audits · 320+ CVEs Remediated · ISO 27001 Aligned',
    client: 'National Tech & Security Auditing Group',
    year: '2024',
    imageUrl: '/src/assets/images/project_cybersecurity_1792477421810.jpg',
    cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477402/AegisSec_Security_Protocol_Specification.pdf',
    featured: true,
    securityFeatures: [
      'Automated dynamic and static application security testing (DAST/SAST)',
      'TLS 1.3 strict cipher suite enforcement and certificate pinning',
      'Role-Based Access Control with hardware key MFA (FIDO2/WebAuthn)',
      'Encrypted forensic audit log pipeline with SHA-256 integrity trees'
    ],
  },
  {
    id: 'proj-3',
    title: 'GovVerify Digital Credential Protocol',
    tagline: 'Tamper-evident public service document & digital certificate validation engine',
    description: 'Engineered a national-scale public service verification protocol in Rwanda that allows citizens, universities, and commercial entities to verify educational degrees, commercial permits, and land titles via QR-based verifiable credentials with Django verification APIs.',
    category: 'GovTech & Public Infrastructure',
    tags: ['React', 'TypeScript', 'Python Django', 'DRF', 'PostgreSQL', 'Cryptography', 'PWA'],
    liveUrl: 'https://govverify.rw',
    githubUrl: 'https://github.com/rukundojd/govverify-engine',
    metrics: '50k+ Daily Queries · Sub-40ms Verification · 100% Tamper Detection',
    client: 'Rwanda Public Sector Technology Initiative',
    year: '2024',
    imageUrl: '/src/assets/images/project_fintech_1792477420911.jpg',
    cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477403/GovVerify_Cryptographic_Spec.pdf',
    featured: false,
    securityFeatures: [
      'Ed25519 asymmetric signature verification',
      'Zero-knowledge proof validation for confidential attributes',
      'Distributed rate limiting preventing enumeration attacks',
      'Content-Security-Policy strict nonce enforcement'
    ],
  },
  {
    id: 'proj-4',
    title: 'HealthBridge Rural EMR & Telehealth Suite',
    tagline: 'End-to-end encrypted medical consultation & patient health record platform',
    description: 'Designed an offline-first electronic medical records system connecting district clinics with referral specialists in Kigali. Built with Django Channels for real-time signaling, differential synchronization, and FHIR standard interoperability.',
    category: 'Full-Stack Architecture',
    tags: ['React', 'Django Channels', 'WebSockets', 'PostgreSQL', 'Tailwind CSS'],
    liveUrl: 'https://healthbridge.rw',

    githubUrl: 'https://github.com/rukundojd/healthbridge-emr',
    metrics: '18 District Clinics Connected · 12,000+ Encrypted Consultations',
    client: 'Community Health Tech Innovation Project',
    year: '2023',
    imageUrl: '/src/assets/images/project_cybersecurity_1792477421810.jpg',
    cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477404/HealthBridge_HIPAA_Compliance.pdf',
    featured: false,
    securityFeatures: [
      'End-to-end encrypted patient chat and telemetry',
      'AES-256 local encrypted SQLite storage in PWA client',
      'Strict audit trails adhering to national health data privacy laws',
      'Role-segmented patient records preventing unauthorized viewing'
    ],
  },
];

export const DEFAULT_GALLERY: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Africa Tech Summit Kigali - Keynote & Innovation Finalist',
    eventType: 'Summit & Keynote',
    date: 'February 2025',
    location: 'Kigali Convention Centre, Rwanda',
    role: 'Lead Presenter & Technical Finalist',
    description: 'Presented scalable fintech payment switches and high-security architectural patterns to an audience of 1,200+ continental founders, investors, and policymakers.',
    imageUrl: '/src/assets/images/gallery_hackathon_1792477422094.jpg',
    cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477410/Africa_Tech_Summit_Presentation.pdf',
    achievement: '1st Runner-Up FinTech Architecture Innovation Award',
  },
  {
    id: 'gal-2',
    title: 'East Africa Cyber Defense Drill & CTF Championship',
    eventType: 'Cyber Defense & CTF',
    date: 'November 2024',
    location: 'Norrsken House Kigali & Regional Network',
    role: 'Blue Team Lead & Incident Responder',
    description: 'Commanded the primary defense perimeter in a 48-hour live adversary simulation. Defended simulated SCADA and banking infrastructure against multi-vector ransomware and APT exploits.',
    imageUrl: '/src/assets/images/gallery_ctf_defense_1792477422263.jpg',
    cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477411/Cyber_Defense_Certificate_Honor.pdf',
    achievement: 'Ranked #1 Defensive Security Team in East Africa',
  },
  {
    id: 'gal-3',
    title: 'Rwanda YouthConnekt Tech Hackathon & Mentorship',
    eventType: 'Innovation Hackathon',
    date: 'August 2024',
    location: 'Intare Conference Arena, Kigali',
    role: 'Technical Mentor & Senior Code Reviewer',
    description: 'Mentored over 60 aspiring young Rwandan developers on building secure REST APIs, clean React state management, and modern CI/CD pipelines for local impact.',
    imageUrl: '/src/assets/images/gallery_hackathon_1792477422094.jpg',
    cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477412/YouthConnekt_Mentor_Commendation.pdf',
    achievement: 'Awarded RDB Mentorship Excellence Recognition',
  },
  {
    id: 'gal-4',
    title: 'National Information Security Workshop (RISA / Kigali)',
    eventType: 'Technical Workshop',
    date: 'March 2024',
    location: 'Kigali Marriott & RISA Tech Hub',
    role: 'Security Workshop Facilitator',
    description: 'Delivered an intensive hands-on lab on OWASP Top 10 API Security Risks, automated secret management, and DevSecOps pipelines for 40+ corporate IT managers.',
    imageUrl: '/src/assets/images/gallery_ctf_defense_1792477422263.jpg',
    cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477413/RISA_Security_Workshop_Syllabus.pdf',
    achievement: 'Certified Master Workshop Instructor',
  },
];

export const DEFAULT_EXPERIENCES: Experience[] = [
  {
    id: 'exp-1',
    role: 'Lead Cybersecurity & Software Architect',
    company: 'Kigali Tech Innovations & Cloud Systems',
    location: 'Kigali, Rwanda',
    period: '2023 - Present',
    type: 'Full-Time',
    summary: 'Overseeing enterprise software architecture and security engineering across distributed web systems, payment rails, and cloud microservices.',
    achievements: [
      'Led zero-downtime refactoring of monolithic backend into containerized Python Django & DRF microservices with Celery background workers, cutting response latency by 58%.',
      'Established DevSecOps automated scanning pipeline preventing critical CVE deployments with 100% CI/CD coverage.',
      'Authored corporate security policies and incident response playbooks aligned with ISO 27001 and East Africa Data Protection standards.'
    ],
    technologies: ['React', 'Python Django', 'Django REST Framework', 'PostgreSQL', 'Docker', 'Kubernetes', 'Celery', 'Redis', 'AWS'],
  },
  {
    id: 'exp-2',
    role: 'Senior Full-Stack Developer & Security Lead',
    company: 'East Africa Digital Payments Consortium',
    location: 'Kigali, Rwanda / Regional',
    period: '2020 - 2023',
    type: 'Full-Time',
    summary: 'Engineered high-concurrency payment switches, mobile wallet integrations, and fraud-detection engines for commercial clients across Rwanda, Kenya, and Uganda.',
    achievements: [
      'Designed and deployed asynchronous USSD webhook orchestrator using Django and Celery managing peak loads of 1,200 concurrent requests during salary cycles.',
      'Conducted quarterly penetration tests and code audits on core ledger APIs, remediating high-risk vulnerabilities prior to audit certification.',
      'Spearheaded frontend redesign into a lightning-fast React single-page app, reducing merchant portal load time to under 800ms.'
    ],
    technologies: ['React', 'TypeScript', 'Python Django', 'DRF', 'PostgreSQL', 'Tailwind CSS', 'Kafka', 'Celery'],
  },
  {
    id: 'exp-3',
    role: 'Web Application Engineer & Security Analyst',
    company: 'Rwanda Tech & Digital Solutions Hub',
    location: 'Kigali, Rwanda',
    period: '2017 - 2020',
    type: 'Full-Time',
    summary: 'Developed modern web applications for public administration and private enterprise clients while providing vulnerability assessments and technical support.',
    achievements: [
      'Built 15+ custom web platforms with responsive Tailwind CSS interfaces and resilient backend REST APIs.',
      'Identified and resolved critical SQL injection and cross-site scripting (XSS) vulnerabilities in legacy government portals.',
      'Trained internal engineering squads on secure coding guidelines and Git flow best practices.'
    ],
    technologies: ['JavaScript', 'React', 'Python', 'Django', 'PostgreSQL', 'Linux Administration', 'Git'],
  },
];

export const DEFAULT_SKILL_CATEGORIES: SkillCategory[] = [
  {
    name: 'Frontend & Web Applications',
    skills: [
      { name: 'React 19 & Next.js Architecture', level: 96, highlights: 'Server Components, dynamic routing, state hydration' },
      { name: 'TypeScript & Modern JavaScript', level: 95, highlights: 'Strict type safety, generics, modular design' },
      { name: 'Tailwind CSS & Responsive UI', level: 98, highlights: 'Mobile-first, anti-slop, accessible micro-interactions' },
      { name: 'Performance Optimization & PWA', level: 92, highlights: 'Lighthouse 98+, offline caching, service workers' },
    ],
  },
  {
    name: 'Backend & Database Systems (Django Ecosystem)',
    skills: [
      { name: 'Django & Django REST Framework (DRF)', level: 96, highlights: 'ModelSerializers, ViewSets, JWT auth, custom permissions, ORM tuning' },
      { name: 'PostgreSQL & Relational Data Design', level: 94, highlights: 'Transactions, index optimization, connection pooling, ACID' },
      { name: 'Django Channels & Celery Workers', level: 92, highlights: 'Async task queues, Redis broker, WebSockets, background jobs' },
      { name: 'Django Security Middleware & Hardening', level: 95, highlights: 'CSRF defense, SQL injection protection, strict CORS, clickjacking' },
    ],
  },

  {
    name: 'Cybersecurity & Offensive / Defensive Auditing',
    skills: [
      { name: 'Penetration Testing & Vulnerability Assessment', level: 94, highlights: 'Burp Suite, OWASP Top 10, network scans' },
      { name: 'Zero-Trust Architecture & Identity', level: 92, highlights: 'OAuth2, JWT, mTLS, RBAC, WebAuthn' },
      { name: 'Secure Code Review & DevSecOps', level: 95, highlights: 'SAST/DAST, Snyk, SonarQube, secret scanning' },
      { name: 'Incident Response & Digital Forensics', level: 87, highlights: 'Threat triage, log forensics, attack analysis' },
    ],
  },
  {
    name: 'DevOps, Cloud & Infrastructure',
    skills: [
      { name: 'Docker & Containerization', level: 92, highlights: 'Multi-stage builds, minimal alpine hardening' },
      { name: 'CI/CD Pipelines & GitHub Actions', level: 90, highlights: 'Automated test suites, security gates, deploy scripts' },
      { name: 'Linux Server Hardening & NGINX', level: 94, highlights: 'UFW, SSH key policies, reverse proxy configurations' },
      { name: 'Cloudinary Asset & Document Management', level: 96, highlights: 'Zero-DB doc storage, signed uploads, CDN delivery' },
    ],
  },
];

export const DEFAULT_CERTIFICATIONS: Certification[] = [
  {
    id: 'cert-1',
    title: 'Certified Ethical Hacker (CEH v12)',
    issuer: 'EC-Council',
    date: '2024',
    credentialId: 'ECC-78192-JDR',
    credentialUrl: 'https://eccouncil.org/verify',
    cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477420/CEH_Certificate.pdf',
  },
  {
    id: 'cert-2',
    title: 'CompTIA Security+ (SY0-701)',
    issuer: 'CompTIA',
    date: '2023',
    credentialId: 'COMP-SEC-49120',
    credentialUrl: 'https://comptia.org/verify',
    cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477421/CompTIA_SecurityPlus.pdf',
  },
  {
    id: 'cert-3',
    title: 'AWS Certified Solutions Architect - Associate',
    issuer: 'Amazon Web Services',
    date: '2024',
    credentialId: 'AWS-PSA-882109',
    credentialUrl: 'https://aws.amazon.com/verification',
    cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477422/AWS_Solutions_Architect.pdf',
  },
  {
    id: 'cert-4',
    title: 'RISA Accredited Information Security Professional',
    issuer: 'Rwanda Information Society Authority',
    date: '2023',
    credentialId: 'RISA-SEC-RW-091',
    credentialUrl: 'https://risa.rw/credentials',
    cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477423/RISA_Accreditation.pdf',
  },
];

export const DEFAULT_EDUCATION: Education[] = [
  {
    degree: 'B.Sc. in Computer Science & Software Engineering',
    institution: 'University of Rwanda, College of Science and Technology',
    location: 'Kigali, Rwanda',
    period: '2013 - 2017',
    honors: 'Graduated with First Class Honors · President of Cybersecurity & Coding Society',
  },
  {
    degree: 'Advanced Postgraduate Specialization in Information Security & DevSecOps',
    institution: 'Carnegie Mellon University Africa (Professional Executive Fellowship)',
    location: 'Kigali Innovation City, Rwanda',
    period: '2021 - 2022',
    honors: 'Distinction in Cryptographic Protocols and Enterprise Network Hardening',
  },
];

const STORAGE_KEY = 'jean_de_dieu_rukundo_portfolio_data_v2';


export function loadPortfolioData(): PortfolioData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      const initial: PortfolioData = {
        settings: DEFAULT_SETTINGS,
        projects: DEFAULT_PROJECTS,
        gallery: DEFAULT_GALLERY,
        experiences: DEFAULT_EXPERIENCES,
        skills: DEFAULT_SKILL_CATEGORIES,
        certifications: DEFAULT_CERTIFICATIONS,
        education: DEFAULT_EDUCATION,
        messages: [],
      };
      savePortfolioData(initial);
      return initial;
    }
    const parsed = JSON.parse(raw);
    return {
      settings: { ...DEFAULT_SETTINGS, ...parsed.settings },
      projects: parsed.projects && parsed.projects.length > 0 ? parsed.projects : DEFAULT_PROJECTS,
      gallery: parsed.gallery && parsed.gallery.length > 0 ? parsed.gallery : DEFAULT_GALLERY,
      experiences: parsed.experiences && parsed.experiences.length > 0 ? parsed.experiences : DEFAULT_EXPERIENCES,
      skills: parsed.skills && parsed.skills.length > 0 ? parsed.skills : DEFAULT_SKILL_CATEGORIES,
      certifications: parsed.certifications && parsed.certifications.length > 0 ? parsed.certifications : DEFAULT_CERTIFICATIONS,
      education: parsed.education && parsed.education.length > 0 ? parsed.education : DEFAULT_EDUCATION,
      messages: parsed.messages || [],
    };
  } catch (e) {
    console.error('Failed to load portfolio data from storage:', e);
    return {
      settings: DEFAULT_SETTINGS,
      projects: DEFAULT_PROJECTS,
      gallery: DEFAULT_GALLERY,
      experiences: DEFAULT_EXPERIENCES,
      skills: DEFAULT_SKILL_CATEGORIES,
      certifications: DEFAULT_CERTIFICATIONS,
      education: DEFAULT_EDUCATION,
      messages: [],
    };
  }
}

export function savePortfolioData(data: PortfolioData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('Failed to save portfolio data to storage:', e);
  }
}

export function resetPortfolioData(): PortfolioData {
  const initial: PortfolioData = {
    settings: DEFAULT_SETTINGS,
    projects: DEFAULT_PROJECTS,
    gallery: DEFAULT_GALLERY,
    experiences: DEFAULT_EXPERIENCES,
    skills: DEFAULT_SKILL_CATEGORIES,
    certifications: DEFAULT_CERTIFICATIONS,
    education: DEFAULT_EDUCATION,
    messages: [],
  };
  savePortfolioData(initial);
  return initial;
}

// Asynchronous Backend API Synchronization
export async function syncWithBackend(): Promise<PortfolioData | null> {
  try {
    const res = await fetch('/api/portfolio');
    if (!res.ok) return null;
    const backendData: PortfolioData = await res.json();
    savePortfolioData(backendData);
    return backendData;
  } catch (err) {
    // Backend offline or starting up, fall back seamlessly to local storage
    return null;
  }
}

export async function submitContactMessage(msg: {
  name: string;
  email: string;
  organization?: string;
  subject?: string;
  message: string;
  honeypot?: string;
}): Promise<{ success: boolean; integrityHash?: string; error?: string }> {
  try {
    const res = await fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(msg),
    });
    if (!res.ok) {
      const err = await res.json();
      return { success: false, error: err.error || 'Failed to transmit message' };
    }
    const data = await res.json();
    return { success: true, integrityHash: data.integrityHash };
  } catch (err) {
    return { success: false, error: 'Network error communicating with server' };
  }
}

export async function syncProjectsToBackend(projects: Project[], token: string): Promise<boolean> {
  try {
    const res = await fetch('/api/admin/backup/restore', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ ...loadPortfolioData(), projects }),
    });
    return res.ok;
  } catch (err) {
    return false;
  }
}

export async function syncGalleryToBackend(gallery: GalleryItem[], token: string): Promise<boolean> {
  try {
    const res = await fetch('/api/admin/backup/restore', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ ...loadPortfolioData(), gallery }),
    });
    return res.ok;
  } catch (err) {
    return false;
  }
}

export async function syncSettingsToBackend(settings: SiteSettings, token: string): Promise<boolean> {
  try {
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(settings),
    });
    return res.ok;
  } catch (err) {
    return false;
  }
}

