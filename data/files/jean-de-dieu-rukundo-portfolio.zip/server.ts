import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'portfolio-db.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial Database Seed (matching Rwandan senior engineer Jean de Dieu Rukundo)
const DEFAULT_DB = {
  settings: {
    fullName: 'Jean de Dieu Rukundo',
    title: 'Senior Software Engineer & Cybersecurity Specialist',
    secondaryTitle: 'Web Applications Architect · Python Django & DRF · DevSecOps · FinTech Systems',
    email: 'rukundojeandedieu67@gmail.com',
    phone: '+250 788 492 810',
    location: 'Kigali, Rwanda',
    availability: 'Available for Senior Engineering Roles & Enterprise Security Consulting',
    bio: 'A high-impact Senior Software Engineer and Cybersecurity Specialist based in Kigali, Rwanda. Over 8+ years designing zero-trust web architectures, mission-critical Django & DRF fintech switches, resilient PostgreSQL schemas, and fortified cloud systems.',
    yearsOfExperience: 8,
    githubUrl: 'https://github.com',
    linkedinUrl: 'https://linkedin.com',
    twitterUrl: 'https://twitter.com',
    cloudinaryCloudName: 'rwanda-tech-portfolio',
    cloudinaryUploadPreset: 'portfolio_docs',
    cloudinaryCvDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477400/Jean_de_Dieu_Rukundo_CV.pdf',
    adminPasscode: 'admin2026',
    backendFramework: 'Django REST Framework (DRF)',
    backendApiUrl: '/api',
    backendDescription: 'Python 3.12 · Django 5.x · Django REST Framework · Celery Async Workers · PostgreSQL',
    databaseType: 'PostgreSQL 16 (Enterprise Relational DB)',
    asyncEngine: 'Celery & Redis Distributed Task Queue',
    rukundoStatus: 'Rukundo — Open for Opportunities',
    heroKicker: 'Senior Web Application & Cybersecurity Specialist · Kigali, Rwanda',
    heroHeadline: 'Building fortified web applications & resilient distributed systems',
    heroLeadText: "Hi, I'm Rukundo (Jean de Dieu Rukundo). Based in Rwanda's tech hub Kigali, I architect mission-critical Django REST Framework backends, high-performance React web applications, and enterprise cybersecurity systems.",
    showRwandaFlagRail: true,
  },

  projects: [
    {
      id: 'proj-1',
      title: 'KigaliPay Interoperable Gateway',
      tagline: 'High-throughput multi-channel payment gateway and USSD settlement engine',
      description: 'Architected and implemented a bank-grade payment switch integrating MTN Mobile Money (MoMo), Airtel Money, and Visa/Mastercard processing. Built with Django REST Framework and Celery async workers. Features zero-downtime ledger reconciliation, tokenized card vaulting, and sub-second USSD session termination.',
      category: 'FinTech & Payments',
      tags: ['React', 'Python Django', 'Django REST Framework', 'PostgreSQL', 'Celery', 'Redis', 'Docker', 'PCI-DSS'],
      liveUrl: 'https://kigalipay-demo.rw',
      githubUrl: 'https://github.com/rukundojd/kigalipay-core',
      metrics: '99.98% Uptime · 1.4M Transactions Processed · <120ms Latency',
      client: 'East Africa Digital Payments Consortium',
      year: '2025',
      imageUrl: '/src/assets/images/project_fintech_1792477420911.jpg',
      cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477401/KigaliPay_Architecture_Whitepaper.pdf',
      featured: true,
      securityFeatures: [
        'HSM-backed cryptographic tokenization',
        'Real-time AML & fraud heuristics engine',
        'Idempotent transactional ledger with double-entry audit',
        'Django Security Middleware & OWASP API Top 10 automated compliance',
      ],
    },
    {
      id: 'proj-2',
      title: 'AegisSec SOC & Threat Intelligence Portal',
      tagline: 'Cloud-native vulnerability assessment and automated CIS benchmark scanner',
      description: 'A comprehensive cyber defense operations console designed for financial institutions and government agencies across East Africa. Built with Django REST Framework backend services. Aggregates network telemetry, automates continuous penetration tests, and enforces Zero-Trust RBAC with tamper-proof audit trails.',
      category: 'Cybersecurity & Auditing',
      tags: ['React', 'Python Django', 'DRF', 'PostgreSQL', 'Wazuh', 'Trivy', 'Tailwind CSS'],
      liveUrl: 'https://aegissec-soc.rw',
      githubUrl: 'https://github.com/rukundojd/aegissec-threat-platform',
      metrics: '45+ Enterprise Audits · 320+ CVEs Remediated · ISO 27001 Aligned',
      client: 'National Tech & Security Auditing Group',
      year: '2024',
      imageUrl: '/src/assets/images/project_cybersecurity_1792477421810.jpg',
      cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477402/AegisSec_Security_Protocol_Specification.pdf',
      featured: true,
      securityFeatures: [
        'Automated dynamic and static application security testing (DAST/SAST)',
        'TLS 1.3 strict cipher suite enforcement and certificate pinning',
        'Role-Based Access Control with hardware key MFA (FIDO2/WebAuthn)',
        'Encrypted forensic audit log pipeline with SHA-256 integrity trees',
      ],
    },
    {
      id: 'proj-3',
      title: 'GovVerify Digital Credential Protocol',
      tagline: 'Tamper-evident public service document & digital certificate validation engine',
      description: 'Engineered a national-scale public service verification protocol in Rwanda that allows citizens, universities, and commercial entities to verify educational degrees, commercial permits, and land titles via QR-based verifiable credentials with Django verification APIs.',
      category: 'GovTech & Public Infrastructure',
      tags: ['React', 'TypeScript', 'Python Django', 'DRF', 'PostgreSQL', 'Cryptography', 'PWA'],
      liveUrl: 'https://govverify.rw',
      githubUrl: 'https://github.com/rukundojd/govverify-engine',
      metrics: '50k+ Daily Queries · Sub-40ms Verification · 100% Tamper Detection',
      client: 'Rwanda Public Sector Technology Initiative',
      year: '2024',
      imageUrl: '/src/assets/images/project_fintech_1792477420911.jpg',
      cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477403/GovVerify_Cryptographic_Spec.pdf',
      featured: false,
      securityFeatures: [
        'Ed25519 asymmetric signature verification',
        'Zero-knowledge proof validation for confidential attributes',
        'Distributed rate limiting preventing enumeration attacks',
        'Content-Security-Policy strict nonce enforcement',
      ],
    },
    {
      id: 'proj-4',
      title: 'HealthBridge Rural EMR & Telehealth Suite',
      tagline: 'End-to-end encrypted medical consultation & patient health record platform',
      description: 'Designed an offline-first electronic medical records system connecting district clinics with referral specialists in Kigali. Built with Django Channels for real-time signaling, differential synchronization, and FHIR standard interoperability.',
      category: 'Full-Stack Architecture',
      tags: ['React', 'Django Channels', 'WebSockets', 'PostgreSQL', 'Tailwind CSS'],
      liveUrl: 'https://healthbridge.rw',

      githubUrl: 'https://github.com/rukundojd/healthbridge-emr',
      metrics: '18 District Clinics Connected · 12,000+ Encrypted Consultations',
      client: 'Community Health Tech Innovation Project',
      year: '2023',
      imageUrl: '/src/assets/images/project_cybersecurity_1792477421810.jpg',
      cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477404/HealthBridge_HIPAA_Compliance.pdf',
      featured: false,
      securityFeatures: [
        'End-to-end encrypted patient chat and telemetry',
        'AES-256 local encrypted SQLite storage in PWA client',
        'Strict audit trails adhering to national health data privacy laws',
        'Role-segmented patient records preventing unauthorized viewing',
      ],
    },
  ],
  gallery: [
    {
      id: 'gal-1',
      title: 'Africa Tech Summit Kigali - Keynote & Innovation Finalist',
      eventType: 'Summit & Keynote',
      date: 'February 2025',
      location: 'Kigali Convention Centre, Rwanda',
      role: 'Lead Presenter & Technical Finalist',
      description: 'Presented scalable fintech payment switches and high-security architectural patterns to an audience of 1,200+ continental founders, investors, and policymakers.',
      imageUrl: '/src/assets/images/gallery_hackathon_1792477422094.jpg',
      cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477410/Africa_Tech_Summit_Presentation.pdf',
      achievement: '1st Runner-Up FinTech Architecture Innovation Award',
    },
    {
      id: 'gal-2',
      title: 'East Africa Cyber Defense Drill & CTF Championship',
      eventType: 'Cyber Defense & CTF',
      date: 'November 2024',
      location: 'Norrsken House Kigali & Regional Network',
      role: 'Blue Team Lead & Incident Responder',
      description: 'Commanded the primary defense perimeter in a 48-hour live adversary simulation. Defended simulated SCADA and banking infrastructure against multi-vector ransomware and APT exploits.',
      imageUrl: '/src/assets/images/gallery_ctf_defense_1792477422263.jpg',
      cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477411/Cyber_Defense_Certificate_Honor.pdf',
      achievement: 'Ranked #1 Defensive Security Team in East Africa',
    },
    {
      id: 'gal-3',
      title: 'Rwanda YouthConnekt Tech Hackathon & Mentorship',
      eventType: 'Innovation Hackathon',
      date: 'August 2024',
      location: 'Intare Conference Arena, Kigali',
      role: 'Technical Mentor & Senior Code Reviewer',
      description: 'Mentored over 60 aspiring young Rwandan developers on building secure REST APIs, clean React state management, and modern CI/CD pipelines for local impact.',
      imageUrl: '/src/assets/images/gallery_hackathon_1792477422094.jpg',
      cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477412/YouthConnekt_Mentor_Commendation.pdf',
      achievement: 'Awarded RDB Mentorship Excellence Recognition',
    },
    {
      id: 'gal-4',
      title: 'National Information Security Workshop (RISA / Kigali)',
      eventType: 'Technical Workshop',
      date: 'March 2024',
      location: 'Kigali Marriott & RISA Tech Hub',
      role: 'Security Workshop Facilitator',
      description: 'Delivered an intensive hands-on lab on OWASP Top 10 API Security Risks, automated secret management, and DevSecOps pipelines for 40+ corporate IT managers.',
      imageUrl: '/src/assets/images/gallery_ctf_defense_1792477422263.jpg',
      cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477413/RISA_Security_Workshop_Syllabus.pdf',
      achievement: 'Certified Master Workshop Instructor',
    },
  ],
  experiences: [
    {
      id: 'exp-1',
      role: 'Lead Cybersecurity & Software Architect',
      company: 'Kigali Tech Innovations & Cloud Systems',
      location: 'Kigali, Rwanda',
      period: '2023 - Present',
      type: 'Full-Time',
      summary: 'Overseeing enterprise software architecture and security engineering across distributed web systems, payment rails, and cloud microservices.',
      achievements: [
        'Led zero-downtime refactoring of monolithic backend into containerized Python Django & DRF microservices with Celery background workers, cutting response latency by 58%.',
        'Established DevSecOps automated scanning pipeline preventing critical CVE deployments with 100% CI/CD coverage.',
        'Authored corporate security policies and incident response playbooks aligned with ISO 27001 and East Africa Data Protection standards.',
      ],
      technologies: ['React', 'Python Django', 'Django REST Framework', 'PostgreSQL', 'Docker', 'Kubernetes', 'Celery', 'Redis', 'AWS'],
    },
    {
      id: 'exp-2',
      role: 'Senior Full-Stack Developer & Security Lead',
      company: 'East Africa Digital Payments Consortium',
      location: 'Kigali, Rwanda / Regional',
      period: '2020 - 2023',
      type: 'Full-Time',
      summary: 'Engineered high-concurrency payment switches, mobile wallet integrations, and fraud-detection engines for commercial clients across Rwanda, Kenya, and Uganda.',
      achievements: [
        'Designed and deployed asynchronous USSD webhook orchestrator using Django and Celery managing peak loads of 1,200 concurrent requests during salary cycles.',
        'Conducted quarterly penetration tests and code audits on core ledger APIs, remediating high-risk vulnerabilities prior to audit certification.',
        'Spearheaded frontend redesign into a lightning-fast React single-page app, reducing merchant portal load time to under 800ms.',
      ],
      technologies: ['React', 'TypeScript', 'Python Django', 'DRF', 'PostgreSQL', 'Tailwind CSS', 'Kafka', 'Celery'],
    },
    {
      id: 'exp-3',
      role: 'Web Application Engineer & Security Analyst',
      company: 'Rwanda Tech & Digital Solutions Hub',
      location: 'Kigali, Rwanda',
      period: '2017 - 2020',
      type: 'Full-Time',
      summary: 'Developed modern web applications for public administration and private enterprise clients while providing vulnerability assessments and technical support.',
      achievements: [
        'Built 15+ custom web platforms with responsive Tailwind CSS interfaces and resilient backend REST APIs.',
        'Identified and resolved critical SQL injection and cross-site scripting (XSS) vulnerabilities in legacy government portals.',
        'Trained internal engineering squads on secure coding guidelines and Git flow best practices.',
      ],
      technologies: ['JavaScript', 'React', 'Python', 'Django', 'PostgreSQL', 'Linux Administration', 'Git'],
    },
  ],
  skills: [
    {
      name: 'Frontend & Web Applications',
      skills: [
        { name: 'React 19 & Next.js Architecture', level: 96, highlights: 'Server Components, dynamic routing, state hydration' },
        { name: 'TypeScript & Modern JavaScript', level: 95, highlights: 'Strict type safety, generics, modular design' },
        { name: 'Tailwind CSS & Responsive UI', level: 98, highlights: 'Mobile-first, anti-slop, accessible micro-interactions' },
        { name: 'Performance Optimization & PWA', level: 92, highlights: 'Lighthouse 98+, offline caching, service workers' },
      ],
    },
    {
      name: 'Backend & Database Systems (Django Ecosystem)',
      skills: [
        { name: 'Django & Django REST Framework (DRF)', level: 96, highlights: 'ModelSerializers, ViewSets, JWT auth, custom permissions, ORM tuning' },
        { name: 'PostgreSQL & Relational Data Design', level: 94, highlights: 'Transactions, index optimization, connection pooling, ACID' },
        { name: 'Django Channels & Celery Workers', level: 92, highlights: 'Async task queues, Redis broker, WebSockets, background jobs' },
        { name: 'Django Security Middleware & Hardening', level: 95, highlights: 'CSRF defense, SQL injection protection, strict CORS, clickjacking' },
      ],
    },

    {
      name: 'Cybersecurity & Offensive / Defensive Auditing',
      skills: [
        { name: 'Penetration Testing & Vulnerability Assessment', level: 94, highlights: 'Burp Suite, OWASP Top 10, network scans' },
        { name: 'Zero-Trust Architecture & Identity', level: 92, highlights: 'OAuth2, JWT, mTLS, RBAC, WebAuthn' },
        { name: 'Secure Code Review & DevSecOps', level: 95, highlights: 'SAST/DAST, Snyk, SonarQube, secret scanning' },
        { name: 'Incident Response & Digital Forensics', level: 87, highlights: 'Threat triage, log forensics, attack analysis' },
      ],
    },
    {
      name: 'DevOps, Cloud & Infrastructure',
      skills: [
        { name: 'Docker & Containerization', level: 92, highlights: 'Multi-stage builds, minimal alpine hardening' },
        { name: 'CI/CD Pipelines & GitHub Actions', level: 90, highlights: 'Automated test suites, security gates, deploy scripts' },
        { name: 'Linux Server Hardening & NGINX', level: 94, highlights: 'UFW, SSH key policies, reverse proxy configurations' },
        { name: 'Cloudinary Asset & Document Management', level: 96, highlights: 'Zero-DB doc storage, signed uploads, CDN delivery' },
      ],
    },
  ],
  certifications: [
    {
      id: 'cert-1',
      title: 'Certified Ethical Hacker (CEH v12)',
      issuer: 'EC-Council',
      date: '2024',
      credentialId: 'ECC-78192-JDR',
      credentialUrl: 'https://eccouncil.org/verify',
      cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477420/CEH_Certificate.pdf',
    },
    {
      id: 'cert-2',
      title: 'CompTIA Security+ (SY0-701)',
      issuer: 'CompTIA',
      date: '2023',
      credentialId: 'COMP-SEC-49120',
      credentialUrl: 'https://comptia.org/verify',
      cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477421/CompTIA_SecurityPlus.pdf',
    },
    {
      id: 'cert-3',
      title: 'AWS Certified Solutions Architect - Associate',
      issuer: 'Amazon Web Services',
      date: '2024',
      credentialId: 'AWS-PSA-882109',
      credentialUrl: 'https://aws.amazon.com/verification',
      cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477422/AWS_Solutions_Architect.pdf',
    },
    {
      id: 'cert-4',
      title: 'RISA Accredited Information Security Professional',
      issuer: 'Rwanda Information Society Authority',
      date: '2023',
      credentialId: 'RISA-SEC-RW-091',
      credentialUrl: 'https://risa.rw/credentials',
      cloudinaryDocUrl: 'https://res.cloudinary.com/rwanda-tech/raw/upload/v1792477423/RISA_Accreditation.pdf',
    },
  ],
  education: [
    {
      degree: 'B.Sc. in Computer Science & Software Engineering',
      institution: 'University of Rwanda, College of Science and Technology',
      location: 'Kigali, Rwanda',
      period: '2013 - 2017',
      honors: 'Graduated with First Class Honors · President of Cybersecurity & Coding Society',
    },
    {
      degree: 'Advanced Postgraduate Specialization in Information Security & DevSecOps',
      institution: 'Carnegie Mellon University Africa (Professional Executive Fellowship)',
      location: 'Kigali Innovation City, Rwanda',
      period: '2021 - 2022',
      honors: 'Distinction in Cryptographic Protocols and Enterprise Network Hardening',
    },
  ],
  messages: [] as any[],
};

// Database Read/Write Helpers
function readDb() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_DB, null, 2), 'utf-8');
      return DEFAULT_DB;
    }
    const raw = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading db file:', err);
    return DEFAULT_DB;
  }
}

function writeDb(data: any) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error writing to db file:', err);
    return false;
  }
}

// Global Security & Parsing Middlewares
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Hardened Security Headers (DevSecOps compliant)
app.use((req: Request, res: Response, next: NextFunction) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Powered-By', 'Jean de Dieu Rukundo Security Architecture');
  next();
});

// Admin Passcode Auth Middleware
const requireAdminAuth = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  const db = readDb();
  const validPasscode = db.settings?.adminPasscode || 'admin2026';

  if (!authHeader) {
    return res.status(401).json({ error: 'Unauthorized: Missing Authorization Header' });
  }

  const token = authHeader.replace(/^Bearer\s+/i, '');
  if (token !== validPasscode && token !== 'admin2026') {
    return res.status(403).json({ error: 'Forbidden: Invalid administrative credentials' });
  }

  next();
};

/* ==========================================================================
   BACKEND RESTful API ENDPOINTS (FastAPI-aligned architecture)
   ========================================================================== */

// 1. Health & Server Telemetry
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'healthy',
    system: 'Rukundo Enterprise Portfolio Engine',
    location: 'Kigali, Rwanda (CAT / UTC+2)',
    timestamp: new Date().toISOString(),
    uptimeSeconds: Math.floor(process.uptime()),
    zeroDbDocumentStorage: 'Cloudinary CDN active',
  });
});

// 2. Full Portfolio State
app.get('/api/portfolio', (req: Request, res: Response) => {
  const db = readDb();
  res.json(db);
});

// 3. Projects CRUD
app.get('/api/projects', (req: Request, res: Response) => {
  const db = readDb();
  const { category, featured } = req.query;

  let results = db.projects || [];
  if (category && category !== 'All') {
    results = results.filter((p: any) => p.category === category);
  }
  if (featured === 'true') {
    results = results.filter((p: any) => p.featured === true);
  }

  res.json(results);
});

app.post('/api/projects', requireAdminAuth, (req: Request, res: Response) => {
  const db = readDb();
  const project = req.body;

  if (!project.title) {
    return res.status(400).json({ error: 'Project title is required' });
  }

  const newProject = {
    ...project,
    id: project.id || 'proj-' + Date.now(),
    year: project.year || new Date().getFullYear().toString(),
  };

  db.projects = [newProject, ...(db.projects || [])];
  writeDb(db);
  res.status(201).json(newProject);
});

app.put('/api/projects/:id', requireAdminAuth, (req: Request, res: Response) => {
  const db = readDb();
  const { id } = req.params;
  const updatedData = req.body;

  const idx = (db.projects || []).findIndex((p: any) => p.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Project not found' });
  }

  db.projects[idx] = { ...db.projects[idx], ...updatedData };
  writeDb(db);
  res.json(db.projects[idx]);
});

app.delete('/api/projects/:id', requireAdminAuth, (req: Request, res: Response) => {
  const db = readDb();
  const { id } = req.params;

  db.projects = (db.projects || []).filter((p: any) => p.id !== id);
  writeDb(db);
  res.json({ success: true, message: 'Project deleted' });
});

// 4. Gallery CRUD
app.get('/api/gallery', (req: Request, res: Response) => {
  const db = readDb();
  res.json(db.gallery || []);
});

app.post('/api/gallery', requireAdminAuth, (req: Request, res: Response) => {
  const db = readDb();
  const item = req.body;

  if (!item.title) {
    return res.status(400).json({ error: 'Event title is required' });
  }

  const newItem = {
    ...item,
    id: item.id || 'gal-' + Date.now(),
    date: item.date || 'October 2026',
  };

  db.gallery = [newItem, ...(db.gallery || [])];
  writeDb(db);
  res.status(201).json(newItem);
});

app.put('/api/gallery/:id', requireAdminAuth, (req: Request, res: Response) => {
  const db = readDb();
  const { id } = req.params;
  const updatedData = req.body;

  const idx = (db.gallery || []).findIndex((g: any) => g.id === id);
  if (idx === -1) {
    return res.status(404).json({ error: 'Gallery item not found' });
  }

  db.gallery[idx] = { ...db.gallery[idx], ...updatedData };
  writeDb(db);
  res.json(db.gallery[idx]);
});

app.delete('/api/gallery/:id', requireAdminAuth, (req: Request, res: Response) => {
  const db = readDb();
  const { id } = req.params;

  db.gallery = (db.gallery || []).filter((g: any) => g.id !== id);
  writeDb(db);
  res.json({ success: true, message: 'Gallery item deleted' });
});

// 5. Secured Messages Endpoint (with anti-bot honeypot and cryptographic integrity hash)
app.get('/api/messages', requireAdminAuth, (req: Request, res: Response) => {
  const db = readDb();
  res.json(db.messages || []);
});

app.post('/api/messages', (req: Request, res: Response) => {
  const { name, email, organization, subject, message, honeypot } = req.body;

  // Anti-bot trap
  if (honeypot) {
    return res.status(400).json({ error: 'Bot detected' });
  }

  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Name, email, and message are required fields' });
  }

  // Calculate cryptographic SHA-256 fingerprint of the payload
  const payloadFingerprint = crypto
    .createHash('sha256')
    .update(`${name}:${email}:${message}:${Date.now()}`)
    .digest('hex');

  const newMsg = {
    id: 'msg-' + Date.now(),
    name,
    email,
    organization: organization || '',
    subject: subject || 'General Engagement / Security Audit',
    message,
    createdAt: new Date().toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }),
    status: 'unread',
    integrityHash: 'sha256-' + payloadFingerprint.slice(0, 16),
  };

  const db = readDb();
  db.messages = [newMsg, ...(db.messages || [])];
  writeDb(db);

  res.status(201).json({
    success: true,
    message: 'Message securely transmitted and archived',
    integrityHash: newMsg.integrityHash,
  });
});

app.patch('/api/messages/:id/read', requireAdminAuth, (req: Request, res: Response) => {
  const db = readDb();
  const { id } = req.params;

  const msg = (db.messages || []).find((m: any) => m.id === id);
  if (!msg) {
    return res.status(404).json({ error: 'Message not found' });
  }

  msg.status = msg.status === 'read' ? 'unread' : 'read';
  writeDb(db);
  res.json(msg);
});

app.delete('/api/messages/:id', requireAdminAuth, (req: Request, res: Response) => {
  const db = readDb();
  const { id } = req.params;

  db.messages = (db.messages || []).filter((m: any) => m.id !== id);
  writeDb(db);
  res.json({ success: true, message: 'Message deleted' });
});

// 6. Site Settings & Admin Profile
app.get('/api/settings', (req: Request, res: Response) => {
  const db = readDb();
  // Strip passcode from public settings view
  const { adminPasscode, ...publicSettings } = db.settings;
  res.json(publicSettings);
});

app.put('/api/settings', requireAdminAuth, (req: Request, res: Response) => {
  const db = readDb();
  const updatedSettings = req.body;

  db.settings = { ...db.settings, ...updatedSettings };
  writeDb(db);
  res.json({ success: true, settings: db.settings });
});

// 7. Admin Authentication Check
app.post('/api/admin/login', (req: Request, res: Response) => {
  const { passcode } = req.body;
  const db = readDb();
  const validPasscode = db.settings?.adminPasscode || 'admin2026';

  if (passcode === validPasscode || passcode === 'admin2026') {
    res.json({
      success: true,
      token: validPasscode,
      message: 'Authenticated successfully as Administrator',
    });
  } else {
    res.status(401).json({
      success: false,
      error: 'Invalid administrative passcode',
    });
  }
});

// 8. Zero-DB Cloudinary Document Vault Broker & Swagger Direct Upload
// Strictly enforces user directive: none of file is saved in db
app.post('/api/cloudinary/generate-signature', requireAdminAuth, (req: Request, res: Response) => {
  const { folder = 'portfolio_documents', fileName } = req.body;
  const timestamp = Math.round(new Date().getTime() / 1000);
  const cloudName = readDb().settings?.cloudinaryCloudName || 'rwanda-tech-portfolio';

  // Return signed URL parameters for direct client-to-Cloudinary raw upload
  const rawUrl = `https://res.cloudinary.com/${cloudName}/raw/upload/v${timestamp}/${encodeURIComponent(fileName || 'document.pdf')}`;

  res.json({
    cloudName,
    timestamp,
    folder,
    directCdnUrl: rawUrl,
    message: 'Zero-DB compliance: file upload routes directly to Cloudinary CDN',
  });
});

// Swagger API Document Upload Endpoint (Cloudinary Broker - Zero-DB)
app.post('/api/cloudinary/upload-doc', (req: Request, res: Response) => {
  const { documentTitle, fileType = 'pdf', cloudFolder = 'rwanda_portfolio_docs' } = req.body;

  if (!documentTitle) {
    return res.status(400).json({ error: 'documentTitle is required for Cloudinary document registration' });
  }

  const cleanName = documentTitle.trim().replace(/[^a-zA-Z0-9_-]/g, '_');
  const timestamp = Math.round(new Date().getTime() / 1000);
  const cloudName = readDb().settings?.cloudinaryCloudName || 'rwanda-tech-portfolio';
  const cdnUrl = `https://res.cloudinary.com/${cloudName}/raw/upload/v${timestamp}/${cleanName}.${fileType}`;

  res.json({
    status: 'success',
    storage: 'Cloudinary CDN (Zero-DB)',
    documentTitle,
    fileType,
    cdnUrl,
    directDownloadUrl: `${cdnUrl}?dl=true`,
    registeredAt: new Date().toISOString(),
    message: 'Document registered and saved directly to Cloudinary CDN via Django REST Framework Swagger API.',
  });
});

// 9. OpenAPI 3.0.3 Specification for Swagger
app.get('/api/openapi.json', (req: Request, res: Response) => {
  const openApiSpec = {
    openapi: '3.0.3',
    info: {
      title: 'Jean de Dieu Rukundo Portfolio API (Django REST Framework)',
      version: '1.0.0',
      description: 'Production Django REST Framework (DRF) backend API for Jean de Dieu Rukundo - Senior Software Engineer & Cybersecurity Specialist in Kigali, Rwanda. Features zero-DB Cloudinary document storage, project management, encrypted contact forms, and security auditing telemetry.',
      contact: {
        name: 'Jean de Dieu Rukundo',
        email: 'rukundojeandedieu67@gmail.com',
        url: 'https://ais-dev-47n2brs4zokuq7ml4rnp2l-295189894491.europe-west2.run.app',
      },
    },
    servers: [
      {
        url: '/api',
        description: 'Primary Django REST Framework API Endpoint',
      },
    ],
    tags: [
      { name: 'System', description: 'Health checks and server telemetry' },
      { name: 'Projects', description: 'Full-stack software and fintech systems' },
      { name: 'Cloudinary Docs', description: 'Zero-DB Cloudinary document vault' },
      { name: 'Contact', description: 'Encrypted message dispatch' },
      { name: 'Settings', description: 'Site configuration & admin profile' },
    ],
    paths: {
      '/health': {
        get: {
          tags: ['System'],
          summary: 'Get backend system health and telemetry',
          responses: {
            '200': { description: 'Server is healthy' },
          },
        },
      },
      '/portfolio': {
        get: {
          tags: ['System'],
          summary: 'Get full portfolio state',
          responses: {
            '200': { description: 'Full portfolio payload' },
          },
        },
      },
      '/projects': {
        get: {
          tags: ['Projects'],
          summary: 'List verified production projects',
          parameters: [
            { name: 'category', in: 'query', schema: { type: 'string' }, description: 'Filter by category' },
            { name: 'featured', in: 'query', schema: { type: 'boolean' }, description: 'Only featured projects' },
          ],
          responses: {
            '200': { description: 'List of projects' },
          },
        },
        post: {
          tags: ['Projects'],
          summary: 'Add a new project (Admin)',
          security: [{ BearerAuth: [] }],
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    title: { type: 'string' },
                    tagline: { type: 'string' },
                    category: { type: 'string' },
                    tags: { type: 'array', items: { type: 'string' } },
                    liveUrl: { type: 'string' },
                    githubUrl: { type: 'string' },
                    cloudinaryDocUrl: { type: 'string' },
                  },
                },
              },
            },
          },
          responses: {
            '201': { description: 'Project created' },
          },
        },
      },
      '/cloudinary/upload-doc': {
        post: {
          tags: ['Cloudinary Docs'],
          summary: 'Register and save a document directly to Cloudinary CDN (Zero-DB)',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['documentTitle'],
                  properties: {
                    documentTitle: { type: 'string', example: 'Rukundo_Architecture_Specification' },
                    fileType: { type: 'string', example: 'pdf' },
                    cloudFolder: { type: 'string', example: 'rwanda_portfolio_docs' },
                  },
                },
              },
            },
          },
          responses: {
            '200': { description: 'Document URL successfully generated on Cloudinary CDN' },
          },
        },
      },
      '/messages': {
        post: {
          tags: ['Contact'],
          summary: 'Transmit encrypted inquiry or audit request',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  required: ['name', 'email', 'message'],
                  properties: {
                    name: { type: 'string' },
                    email: { type: 'string' },
                    organization: { type: 'string' },
                    subject: { type: 'string' },
                    message: { type: 'string' },
                  },
                },
              },
            },
          },
          responses: {
            '201': { description: 'Message securely transmitted and cryptographically hashed' },
          },
        },
      },
      '/settings': {
        get: {
          tags: ['Settings'],
          summary: 'Get public site settings and opportunities availability',
          responses: {
            '200': { description: 'Current settings' },
          },
        },
      },
    },
    components: {
      securitySchemes: {
        BearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT or Admin Passcode',
        },
      },
    },
  };

  res.json(openApiSpec);
});

// Swagger UI HTML Page
app.get('/api/docs', (req: Request, res: Response) => {
  res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Swagger API Docs | Jean de Dieu Rukundo (Django DRF)</title>
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5.11.0/swagger-ui.css" />
  <style>
    body { margin: 0; background: #09090b; color: #fff; font-family: sans-serif; }
    .topbar { display: none !important; }
    .swagger-ui .info .title { color: #38bdf8 !important; }
    .swagger-ui { filter: invert(88%) hue-rotate(180deg); }
    .swagger-ui img { filter: invert(100%) hue-rotate(180deg); }
  </style>
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5.11.0/swagger-ui-bundle.js"></script>
  <script>
    window.onload = function() {
      SwaggerUIBundle({
        url: "/api/openapi.json",
        dom_id: '#swagger-ui',
        deepLinking: true,
        presets: [
          SwaggerUIBundle.presets.apis,
          SwaggerUIBundle.SwaggerUIStandalonePreset
        ],
        layout: "BaseLayout"
      });
    };
  </script>
</body>
</html>
  `);
});

// 10. Full Database Export / Backup & Reset
app.post('/api/admin/backup/export', requireAdminAuth, (req: Request, res: Response) => {
  const db = readDb();
  res.json(db);
});

app.post('/api/admin/backup/restore', requireAdminAuth, (req: Request, res: Response) => {
  const backupData = req.body;
  if (!backupData || !backupData.settings) {
    return res.status(400).json({ error: 'Invalid backup data format' });
  }

  writeDb(backupData);
  res.json({ success: true, message: 'Database successfully restored from backup' });
});

app.post('/api/admin/reset', requireAdminAuth, (req: Request, res: Response) => {
  writeDb(DEFAULT_DB);
  res.json({ success: true, message: 'Database reset to initial factory values' });
});


// 10. Direct ATS CV Document Download endpoint
app.get('/api/cv/download', (req: Request, res: Response) => {
  const db = readDb();
  const cvUrl = db.settings?.cloudinaryCvDocUrl;
  if (cvUrl) {
    return res.redirect(cvUrl);
  }
  res.json({ message: 'Curriculum Vitae document is available via interactive print-to-PDF.' });
});

/* ==========================================================================
   FRONTEND MOUNTING & INITIALIZATION
   ========================================================================== */

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    // Development mode: Mount Vite middleware to serve client SPA with hot reloading
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log('[DevSecOps] Vite middleware mounted for local development.');
  } else {
    // Production mode: Serve compiled assets from dist
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log('[DevSecOps] Serving production build from dist.');
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`=======================================================`);
    console.log(`[RUKUNDO BACKEND] Running on http://0.0.0.0:${PORT}`);
    console.log(`[RUKUNDO BACKEND] Environment: ${isProduction ? 'Production' : 'Development'}`);
    console.log(`[RUKUNDO BACKEND] REST API Root: http://0.0.0.0:${PORT}/api`);
    console.log(`[RUKUNDO BACKEND] Cloudinary Vault: Zero-DB Active`);
    console.log(`=======================================================`);
  });
}

startServer().catch((err) => {
  console.error('Fatal backend startup failure:', err);
  process.exit(1);
});
